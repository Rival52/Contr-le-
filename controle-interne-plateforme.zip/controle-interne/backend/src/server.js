require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const authRoutes = require('./routes/auth.routes');
const usersRoutes = require('./routes/users.routes');
const controlesRoutes = require('./routes/controles.routes');
const plansActionRoutes = require('./routes/plansAction.routes');
const fdtRoutes = require('./routes/fdt.routes');
const decisionsCodirRoutes = require('./routes/decisionsCodir.routes');
const { demarrerTachesPlanifiees } = require('./config/scheduler');

const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/controles', controlesRoutes);
app.use('/api/plans-action', plansActionRoutes);
app.use('/api/fdt', fdtRoutes);
app.use('/api/decisions-codir', decisionsCodirRoutes);

// Servir le frontend compilé (build React) en production
const frontendBuildPath = path.join(__dirname, '..', '..', 'frontend', 'build');
app.use(express.static(frontendBuildPath));
app.get('*', (req, res, next) => {
  if (req.path.startsWith('/api')) return next();
  res.sendFile(path.join(frontendBuildPath, 'index.html'));
});

// Gestion des erreurs génériques
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Erreur interne du serveur.' });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Serveur Contrôle Interne démarré sur le port ${PORT}`);
  demarrerTachesPlanifiees();
});
