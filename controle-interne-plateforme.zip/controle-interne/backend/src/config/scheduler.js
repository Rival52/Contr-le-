const cron = require('node-cron');
const { Op } = require('sequelize');
const { PlanAction, Controle, User } = require('../models');
const { notifierEcheanceDepassee } = require('./mailer');

async function verifierEcheancesDepassees() {
  const aujourdHui = new Date().toISOString().slice(0, 10);

  const plansEnRetard = await PlanAction.findAll({
    where: {
      statut: { [Op.notIn]: ['applique', 'abandonne'] },
      date_echeance: { [Op.lt]: aujourdHui },
      notifie_retard: false,
    },
    include: [
      { model: Controle, as: 'controle', attributes: ['code'] },
      { model: User, as: 'rmo', attributes: ['email', 'nom', 'prenom'] },
    ],
  });

  for (const plan of plansEnRetard) {
    if (plan.rmo?.email) {
      await notifierEcheanceDepassee({
        rmoEmail: plan.rmo.email,
        rmoNom: `${plan.rmo.prenom} ${plan.rmo.nom}`,
        planCode: plan.code,
        controleCode: plan.controle?.code,
        dateEcheance: plan.date_echeance,
      });
    }
    plan.notifie_retard = true;
    await plan.save();
  }

  if (plansEnRetard.length > 0) {
    console.log(`[Tâche planifiée] ${plansEnRetard.length} notification(s) de retard envoyée(s).`);
  }
}

// S'exécute tous les jours à 7h du matin (heure du serveur)
function demarrerTachesPlanifiees() {
  cron.schedule('0 7 * * *', verifierEcheancesDepassees);
  console.log('Tâches planifiées démarrées (vérification des échéances tous les jours à 7h).');
}

module.exports = { demarrerTachesPlanifiees, verifierEcheancesDepassees };
