const cron = require('node-cron');
const { Op } = require('sequelize');
const { PlanAction, Controle, User, DecisionCodir } = require('../models');
const { notifierEcheanceDepassee, notifierEcheanceDecisionCodir } = require('./mailer');

async function verifierEcheancesDepassees() {
  const aujourdHui = new Date().toISOString().slice(0, 10);

  const plansEnRetard = await PlanAction.findAll({
    where: {
      statut: { [Op.notIn]: ['applique', 'abandonne'] },
      date_echeance: { [Op.lt]: aujourdHui },
      notifie_retard: false,
    },
    include: [
      { model: Controle, as: 'controle', attributes: ['code'] },
      { model: User, as: 'rmo', attributes: ['email', 'nom', 'prenom'] },
    ],
  });

  for (const plan of plansEnRetard) {
    if (plan.rmo?.email) {
      await notifierEcheanceDepassee({
        rmoEmail: plan.rmo.email,
        rmoNom: `${plan.rmo.prenom} ${plan.rmo.nom}`,
        planCode: plan.code,
        controleCode: plan.controle?.code,
        dateEcheance: plan.date_echeance,
      });
    }
    plan.notifie_retard = true;
    await plan.save();
  }

  const decisionsEnRetard = await DecisionCodir.findAll({
    where: {
      statut: { [Op.notIn]: ['applique', 'abandonne'] },
      date_echeance: { [Op.lt]: aujourdHui },
      notifie_retard: false,
    },
    include: [{ model: User, as: 'responsable', attributes: ['email', 'nom', 'prenom'] }],
  });

  for (const decision of decisionsEnRetard) {
    if (decision.responsable?.email) {
      await notifierEcheanceDecisionCodir({
        responsableEmail: decision.responsable.email,
        responsableNom: `${decision.responsable.prenom} ${decision.responsable.nom}`,
        decisionCode: decision.code,
        intitule: decision.intitule,
        dateEcheance: decision.date_echeance,
      });
    }
    decision.notifie_retard = true;
    await decision.save();
  }

  const total = plansEnRetard.length + decisionsEnRetard.length;
  if (total > 0) {
    console.log(`[Tâche planifiée] ${plansEnRetard.length} plan(s) d'action + ${decisionsEnRetard.length} décision(s) CODIR en retard notifié(s).`);
  }
}

// S'exécute tous les jours à 7h du matin (heure du serveur)
function demarrerTachesPlanifiees() {
  cron.schedule('0 7 * * *', verifierEcheancesDepassees);
  console.log('Tâches planifiées démarrées (vérification des échéances tous les jours à 7h).');
}

module.exports = { demarrerTachesPlanifiees, verifierEcheancesDepassees };
