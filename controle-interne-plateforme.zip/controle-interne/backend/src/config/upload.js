const multer = require('multer');
const path = require('path');
const fs = require('fs');

function makeStorage(subfolder) {
  const dir = path.join(__dirname, '..', '..', 'uploads', subfolder);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const ext = path.extname(file.originalname);
      const base = path.basename(file.originalname, ext).replace(/[^a-zA-Z0-9_-]/g, '_');
      cb(null, `${base}_${Date.now()}${ext}`);
    },
  });
}

const uploadFDT = multer({ storage: makeStorage('fdt') });
const uploadJustificatif = multer({ storage: makeStorage('justificatifs') });
const uploadExcel = multer({ storage: multer.memoryStorage() }); // traité directement en mémoire

module.exports = { uploadFDT, uploadJustificatif, uploadExcel };
