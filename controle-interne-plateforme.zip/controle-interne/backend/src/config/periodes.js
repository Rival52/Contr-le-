// Calcule le libellé de période courante selon la périodicité d'un contrôle.
// C'est ce libellé qui sert à savoir si le contrôle a déjà été fait sur la période en cours.

function pad(n) { return String(n).padStart(2, '0'); }

function numeroSemaineISO(date) {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
}

function periodeCourante(periodicite, date = new Date()) {
  const annee = date.getFullYear();
  const mois = date.getMonth() + 1; // 1-12
  const trimestre = Math.ceil(mois / 3);
  const semestre = mois <= 6 ? 1 : 2;

  switch (periodicite) {
    case 'Hebdomadaire':
      return `${annee}-W${pad(numeroSemaineISO(date))}`;
    case 'Mensuelle':
      return `${annee}-${pad(mois)}`;
    case 'Trimestrielle':
      return `${annee}-T${trimestre}`;
    case 'Semestrielle':
      return `${annee}-S${semestre}`;
    case 'Annuelle':
      return `${annee}`;
    default:
      return `${annee}-${pad(mois)}`;
  }
}

// Libellé lisible pour l'affichage (ex: "Août 2026", "3e trimestre 2026")
const MOIS = ['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'];

function libellePeriode(periodeLabel) {
  if (/^\d{4}-W\d{2}$/.test(periodeLabel)) {
    const [annee, semaine] = periodeLabel.split('-W');
    return `Semaine ${semaine} - ${annee}`;
  }
  if (/^\d{4}-\d{2}$/.test(periodeLabel)) {
    const [annee, mois] = periodeLabel.split('-');
    return `${MOIS[parseInt(mois, 10) - 1]} ${annee}`;
  }
  if (/^\d{4}-T\d$/.test(periodeLabel)) {
    const [annee, t] = periodeLabel.split('-T');
    return `${t}e trimestre ${annee}`;
  }
  if (/^\d{4}-S\d$/.test(periodeLabel)) {
    const [annee, s] = periodeLabel.split('-S');
    return `${s}e semestre ${annee}`;
  }
  return periodeLabel; // année seule
}

module.exports = { periodeCourante, libellePeriode };
