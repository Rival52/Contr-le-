const nodemailer = require('nodemailer');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;

  if (!process.env.SMTP_HOST) {
    console.warn("SMTP non configuré (.env) : les notifications par email sont désactivées.");
    return null;
  }

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === 'true', // false pour le port 587 (STARTTLS), true pour 465
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    },
  });
  return transporter;
}

async function envoyerMail({ to, subject, html }) {
  const t = getTransporter();
  if (!t || !to) return;

  try {
    await t.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to,
      subject,
      html,
    });
  } catch (err) {
    // On ne bloque jamais une action utilisateur à cause d'un email qui échoue
    console.error('Erreur lors de l\'envoi de l\'email :', err.message);
  }
}

function notifierNouvelleActionRMO({ controleurEmail, controleurNom, rmoNom, planCode, controleCode }) {
  return envoyerMail({
    to: controleurEmail,
    subject: `[OPTIKA] Nouvelle action soumise par ${rmoNom} - ${planCode}`,
    html: `
      <p>Bonjour ${controleurNom},</p>
      <p><strong>${rmoNom}</strong> vient de soumettre son fichier d'action pour le plan
      <strong>${planCode}</strong> (contrôle ${controleCode}).</p>
      <p>Merci de vous connecter à la plateforme OPTIKA pour valider ou refuser cette action.</p>
    `,
  });
}

function notifierEcheanceDepassee({ rmoEmail, rmoNom, planCode, controleCode, dateEcheance }) {
  return envoyerMail({
    to: rmoEmail,
    subject: `[OPTIKA] Échéance dépassée - Plan d'action ${planCode}`,
    html: `
      <p>Bonjour ${rmoNom},</p>
      <p>Le plan d'action <strong>${planCode}</strong> (contrôle ${controleCode}) a dépassé sa date
      d'échéance du <strong>${dateEcheance}</strong> sans avoir été clôturé.</p>
      <p>Merci de vous connecter à la plateforme OPTIKA pour régulariser la situation dans les
      meilleurs délais.</p>
    `,
  });
}

function envoyerLienReinitialisation({ email, nom, prenom, lien }) {
  return envoyerMail({
    to: email,
    subject: '[OPTIKA] Réinitialisation de votre mot de passe',
    html: `
      <p>Bonjour ${prenom} ${nom},</p>
      <p>Une demande de réinitialisation de mot de passe a été effectuée pour votre compte OPTIKA.</p>
      <p><a href="${lien}" style="background:#3d4f8f;color:#fff;padding:10px 18px;border-radius:6px;text-decoration:none;display:inline-block;">Réinitialiser mon mot de passe</a></p>
      <p>Ce lien est valable 1 heure. Si vous n'êtes pas à l'origine de cette demande, ignorez simplement cet email.</p>
    `,
  });
}

function notifierEcheanceDecisionCodir({ responsableEmail, responsableNom, decisionCode, intitule, dateEcheance }) {
  return envoyerMail({
    to: responsableEmail,
    subject: `[OPTIKA] Échéance dépassée - Décision CODIR ${decisionCode}`,
    html: `
      <p>Bonjour ${responsableNom},</p>
      <p>La décision CODIR <strong>${decisionCode}</strong> qui vous est confiée a dépassé sa date
      d'échéance du <strong>${dateEcheance}</strong> sans avoir été clôturée.</p>
      <p><em>${intitule?.slice(0, 200)}${intitule?.length > 200 ? '...' : ''}</em></p>
      <p>Merci de vous connecter à la plateforme OPTIKA pour régulariser la situation dans les
      meilleurs délais.</p>
    `,
  });
}

function notifierNouvelleDecisionCodir({ responsableEmail, responsableNom, decisionCode, numero, intitule, dateEcheance }) {
  return envoyerMail({
    to: responsableEmail,
    subject: `[OPTIKA] Nouvelle décision CODIR vous concernant${numero ? ` - N°${numero}` : ''}`,
    html: `
      <p>Bonjour ${responsableNom},</p>
      <p>Le Comité de Direction vous confie l'action suivante à mettre en œuvre :</p>
      <table style="border-collapse:collapse;width:100%;margin:14px 0;">
        <tr style="background:#eaeef8;">
          <td style="padding:8px;border:1px solid #ddd;"><strong>Action</strong></td>
          <td style="padding:8px;border:1px solid #ddd;">${intitule}</td>
        </tr>
        <tr>
          <td style="padding:8px;border:1px solid #ddd;"><strong>Échéance</strong></td>
          <td style="padding:8px;border:1px solid #ddd;">${dateEcheance}</td>
        </tr>
      </table>
      <p>Merci de vous connecter à la plateforme OPTIKA (module "Décisions CODIR") pour suivre
      cette action, la commenter et mettre à jour son statut d'avancement.</p>
    `,
  });
}

module.exports = {
  envoyerMail,
  notifierNouvelleActionRMO,
  notifierEcheanceDepassee,
  envoyerLienReinitialisation,
  notifierEcheanceDecisionCodir,
  notifierNouvelleDecisionCodir,
};
