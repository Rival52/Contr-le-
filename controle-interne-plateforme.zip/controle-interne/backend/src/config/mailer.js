const nodemailer = require('nodemailer');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;

  if (!process.env.SMTP_HOST) {
    console.warn("SMTP non configuré (.env) : les notifications par email sont désactivées.");
    return null;
  }

  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === 'true', // false pour le port 587 (STARTTLS), true pour 465
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASSWORD,
    },
  });
  return transporter;
}

async function envoyerMail({ to, subject, html }) {
  const t = getTransporter();
  if (!t || !to) return;

  try {
    await t.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to,
      subject,
      html,
    });
  } catch (err) {
    // On ne bloque jamais une action utilisateur à cause d'un email qui échoue
    console.error('Erreur lors de l\'envoi de l\'email :', err.message);
  }
}

function notifierNouvelleActionRMO({ controleurEmail, controleurNom, rmoNom, planCode, controleCode }) {
  return envoyerMail({
    to: controleurEmail,
    subject: `[OPTIKA] Nouvelle action soumise par ${rmoNom} - ${planCode}`,
    html: `
      <p>Bonjour ${controleurNom},</p>
      <p><strong>${rmoNom}</strong> vient de soumettre son fichier d'action pour le plan
      <strong>${planCode}</strong> (contrôle ${controleCode}).</p>
      <p>Merci de vous connecter à la plateforme OPTIKA pour valider ou refuser cette action.</p>
    `,
  });
}

function notifierEcheanceDepassee({ rmoEmail, rmoNom, planCode, controleCode, dateEcheance }) {
  return envoyerMail({
    to: rmoEmail,
    subject: `[OPTIKA] Échéance dépassée - Plan d'action ${planCode}`,
    html: `
      <p>Bonjour ${rmoNom},</p>
      <p>Le plan d'action <strong>${planCode}</strong> (contrôle ${controleCode}) a dépassé sa date
      d'échéance du <strong>${dateEcheance}</strong> sans avoir été clôturé.</p>
      <p>Merci de vous connecter à la plateforme OPTIKA pour régulariser la situation dans les
      meilleurs délais.</p>
    `,
  });
}

module.exports = { envoyerMail, notifierNouvelleActionRMO, notifierEcheanceDepassee };
