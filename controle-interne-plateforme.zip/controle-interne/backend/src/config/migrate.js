require('dotenv').config();
const { sequelize } = require('../models');

(async () => {
  try {
    await sequelize.authenticate();
    console.log('Connexion à la base de données réussie.');
    await sequelize.sync({ alter: true });
    console.log('Tables synchronisées avec succès.');
    process.exit(0);
  } catch (err) {
    console.error('Erreur lors de la migration :', err);
    process.exit(1);
  }
})();
