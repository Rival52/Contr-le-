require('dotenv').config();
const bcrypt = require('bcryptjs');
const { sequelize, User } = require('../models');

(async () => {
  try {
    await sequelize.authenticate();

    const email = process.env.ADMIN_EMAIL;
    const password = process.env.ADMIN_PASSWORD;

    if (!email || !password) {
      console.error('ADMIN_EMAIL et ADMIN_PASSWORD doivent être définis dans le fichier .env');
      process.exit(1);
    }

    const existant = await User.findOne({ where: { email } });
    if (existant) {
      console.log('Un compte admin existe déjà avec cet email.');
      process.exit(0);
    }

    const password_hash = await bcrypt.hash(password, 10);
    await User.create({
      nom: 'Administrateur',
      prenom: 'Système',
      email,
      password_hash,
      role: 'admin',
      entite: 'Direction',
      actif: true,
    });

    console.log(`Compte admin créé avec succès : ${email}`);
    process.exit(0);
  } catch (err) {
    console.error('Erreur lors de la création du compte admin :', err);
    process.exit(1);
  }
})();
