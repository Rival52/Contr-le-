const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { Op } = require('sequelize');
const { User } = require('../models');
const { authenticate } = require('../middleware/auth');
const { envoyerLienReinitialisation } = require('../config/mailer');

const router = express.Router();

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: 'Email et mot de passe requis.' });
    }

    const user = await User.findOne({ where: { email } });
    if (!user || !user.actif) {
      return res.status(401).json({ message: 'Identifiants incorrects ou compte désactivé.' });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ message: 'Identifiants incorrects.' });
    }

    const payload = {
      id: user.id,
      email: user.email,
      nom: user.nom,
      prenom: user.prenom,
      role: user.role,
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '8h',
    });

    res.json({ token, user: payload });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur serveur lors de la connexion.' });
  }
});

// GET /api/auth/me
router.get('/me', authenticate, async (req, res) => {
  res.json({ user: req.user });
});

// POST /api/auth/mot-de-passe-oublie
// Réponse volontairement identique que l'email existe ou non, pour ne pas révéler
// quels comptes existent sur la plateforme.
router.post('/mot-de-passe-oublie', async (req, res) => {
  const { email } = req.body;
  const messageGenerique = { message: 'Si un compte existe avec cet email, un lien de réinitialisation a été envoyé.' };

  if (!email) return res.status(400).json({ message: 'Email requis.' });

  try {
    const user = await User.findOne({ where: { email, actif: true } });
    if (user) {
      const token = crypto.randomBytes(32).toString('hex');
      user.reset_token = token;
      user.reset_token_expires = new Date(Date.now() + 60 * 60 * 1000); // 1h
      await user.save();

      const base = process.env.FRONTEND_URL || '';
      const lien = `${base}/reinitialiser-mot-de-passe/${token}`;

      await envoyerLienReinitialisation({
        email: user.email,
        nom: user.nom,
        prenom: user.prenom,
        lien,
      });
    }
    res.json(messageGenerique);
  } catch (err) {
    console.error(err);
    res.json(messageGenerique); // on ne laisse jamais fuiter l'erreur ici
  }
});

// POST /api/auth/reinitialiser-mot-de-passe
router.post('/reinitialiser-mot-de-passe', async (req, res) => {
  const { token, password } = req.body;
  if (!token || !password) {
    return res.status(400).json({ message: 'Token et nouveau mot de passe requis.' });
  }
  if (password.length < 6) {
    return res.status(400).json({ message: 'Le mot de passe doit contenir au moins 6 caractères.' });
  }

  const user = await User.findOne({
    where: { reset_token: token, reset_token_expires: { [Op.gt]: new Date() } },
  });
  if (!user) {
    return res.status(400).json({ message: 'Lien invalide ou expiré. Faites une nouvelle demande.' });
  }

  user.password_hash = await bcrypt.hash(password, 10);
  user.reset_token = null;
  user.reset_token_expires = null;
  await user.save();

  res.json({ message: 'Mot de passe réinitialisé avec succès. Vous pouvez vous connecter.' });
});

module.exports = router;
