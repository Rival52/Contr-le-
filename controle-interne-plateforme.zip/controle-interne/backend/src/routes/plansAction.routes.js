const express = require('express');
const path = require('path');
const { Op } = require('sequelize');
const ExcelJS = require('exceljs');
const { PlanAction, Controle, User, ActionJustificatif } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadJustificatif } = require('../config/upload');
const { notifierNouvelleActionRMO } = require('../config/mailer');

const router = express.Router();
router.use(authenticate);
router.use((req, res, next) => {
  if (req.user.role === 'codir') {
    return res.status(403).json({ message: "Vous n'avez pas accès à ce module." });
  }
  next();
});

function genererCode() {
  return 'PA' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Ajoute un statut d'affichage calculé (échéance dépassée) sans écraser le statut stocké
function withStatutAffiche(plan) {
  const p = plan.toJSON ? plan.toJSON() : plan;
  const dejaFinal = ['applique', 'abandonne'].includes(p.statut);
  const estEnRetard = !dejaFinal && p.date_echeance && new Date(p.date_echeance) < new Date();
  const enCoursOuRefuse = ['non_echu', 'refuse'].includes(p.statut);
  p.statut_affiche = estEnRetard && enCoursOuRefuse ? 'echu' : p.statut;
  return p;
}

// --- Liste des plans d'action ---
// RMO : uniquement ses propres plans. Controleur/Admin : tout, avec filtres.
router.get('/', async (req, res) => {
  const { statut, controle_code, rmo_id } = req.query;
  const where = {};
  if (statut) where.statut = statut;

  if (req.user.role === 'rmo') {
    where.rmo_id = req.user.id;
  } else if (rmo_id) {
    where.rmo_id = rmo_id;
  }

  const include = [
    { model: Controle, as: 'controle', attributes: ['id', 'code', 'processus', 'activite'] },
    { model: User, as: 'rmo', attributes: ['id', 'nom', 'prenom'] },
    { model: User, as: 'controleur', attributes: ['id', 'nom', 'prenom'] },
  ];

  if (controle_code) {
    include[0].where = { code: controle_code };
  }

  const plans = await PlanAction.findAll({ where, include, order: [['date_echeance', 'ASC']] });
  res.json(plans.map(withStatutAffiche));
});

router.get('/:id', async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id, {
    include: [
      { model: Controle, as: 'controle' },
      { model: User, as: 'rmo', attributes: ['id', 'nom', 'prenom'] },
      { model: User, as: 'controleur', attributes: ['id', 'nom', 'prenom'] },
      { model: ActionJustificatif, as: 'justificatifs' },
    ],
  });
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });

  if (req.user.role === 'rmo' && plan.rmo_id !== req.user.id) {
    return res.status(403).json({ message: 'Accès non autorisé à ce plan d\'action.' });
  }

  res.json(withStatutAffiche(plan));
});

// --- Création d'un plan d'action (controleur/admin uniquement) ---
// Le contrôleur indique le code de contrôle + la recommandation + le RMO concerné + échéance
router.post('/', authorize('admin', 'controleur'), async (req, res) => {
  try {
    const { controle_code, recommandation, rmo_id, date_echeance } = req.body;
    if (!controle_code || !recommandation || !rmo_id || !date_echeance) {
      return res.status(400).json({ message: 'Code de contrôle, recommandation, RMO et échéance sont obligatoires.' });
    }

    const controle = await Controle.findOne({ where: { code: { [Op.iLike]: controle_code.trim() } } });
    if (!controle) return res.status(404).json({ message: 'Code de contrôle introuvable.' });

    const rmo = await User.findByPk(rmo_id);
    if (!rmo || rmo.role !== 'rmo') return res.status(400).json({ message: 'RMO invalide.' });

    let code = genererCode();
    // s'assurer de l'unicité (collision très improbable mais on vérifie)
    while (await PlanAction.findOne({ where: { code } })) code = genererCode();

    const plan = await PlanAction.create({
      code,
      controle_id: controle.id,
      recommandation,
      rmo_id,
      controleur_id: req.user.id,
      date_echeance,
      statut: 'non_echu',
    });

    res.status(201).json(plan);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la création du plan d\'action.' });
  }
});

// --- Le RMO ajoute son fichier d'action (justificatif) sur un plan qui lui est assigné ---
router.post('/:id/justificatif', authorize('rmo'), uploadJustificatif.single('fichier'), async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id, {
    include: [
      { model: Controle, as: 'controle', attributes: ['code'] },
      { model: User, as: 'controleur', attributes: ['email', 'nom', 'prenom'] },
    ],
  });
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });
  if (plan.rmo_id !== req.user.id) {
    return res.status(403).json({ message: 'Ce plan d\'action ne vous est pas assigné.' });
  }
  if (['applique', 'abandonne'].includes(plan.statut)) {
    return res.status(400).json({ message: 'Ce plan d\'action est clos et ne peut plus être modifié.' });
  }
  if (!req.file && !req.body.commentaire?.trim()) {
    return res.status(400).json({ message: 'Ajoutez au moins un commentaire ou un fichier avant de soumettre.' });
  }

  const justificatif = await ActionJustificatif.create({
    plan_action_id: plan.id,
    nom_fichier: req.file ? req.file.originalname : null,
    chemin_fichier: req.file ? req.file.filename : null,
    commentaire: req.body.commentaire || null,
    uploaded_by: req.user.id,
  });

  plan.statut = 'en_attente_validation';
  plan.commentaire_refus = null;
  plan.notifie_retard = false;
  await plan.save();

  if (plan.controleur?.email) {
    notifierNouvelleActionRMO({
      controleurEmail: plan.controleur.email,
      controleurNom: `${plan.controleur.prenom} ${plan.controleur.nom}`,
      rmoNom: `${req.user.prenom} ${req.user.nom}`,
      planCode: plan.code,
      controleCode: plan.controle?.code,
    });
  }

  res.status(201).json(justificatif);
});

// --- Le contrôleur valide l'action soumise par le RMO ---
router.put('/:id/valider', authorize('admin', 'controleur'), async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id);
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });

  plan.statut = 'applique';
  plan.commentaire_refus = null;
  await plan.save();
  res.json(plan);
});

// --- Le contrôleur refuse l'action soumise, avec commentaire obligatoire ---
router.put('/:id/refuser', authorize('admin', 'controleur'), async (req, res) => {
  const { commentaire_refus } = req.body;
  if (!commentaire_refus) {
    return res.status(400).json({ message: 'Un commentaire de refus est obligatoire.' });
  }

  const plan = await PlanAction.findByPk(req.params.id);
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });

  plan.statut = 'refuse'; // le RMO voit clairement que son action a été refusée, et doit resoumettre
  plan.commentaire_refus = commentaire_refus;
  await plan.save();
  res.json(plan);
});

// --- Le contrôleur abandonne un plan d'action ---
router.put('/:id/abandonner', authorize('admin', 'controleur'), async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id);
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });

  plan.statut = 'abandonne';
  await plan.save();
  res.json(plan);
});

// --- Modification libre par le contrôleur (échéance, recommandation, RMO...) ---
router.put('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id);
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });

  const { recommandation, rmo_id, date_echeance, statut } = req.body;
  if (recommandation) plan.recommandation = recommandation;
  if (rmo_id) plan.rmo_id = rmo_id;
  if (date_echeance) plan.date_echeance = date_echeance;
  if (statut) plan.statut = statut;
  await plan.save();
  res.json(plan);
});

// --- Suppression d'un plan d'action (admin + controleur) ---
router.delete('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const plan = await PlanAction.findByPk(req.params.id);
  if (!plan) return res.status(404).json({ message: 'Plan d\'action introuvable.' });
  await plan.destroy();
  res.json({ message: 'Plan d\'action supprimé.' });
});

// --- Téléchargement d'un justificatif ---
router.get('/justificatif/:justifId/download', async (req, res) => {
  const justif = await ActionJustificatif.findByPk(req.params.justifId, {
    include: [{ model: PlanAction, attributes: ['rmo_id'] }],
  });
  if (!justif) return res.status(404).json({ message: 'Fichier introuvable.' });
  if (!justif.chemin_fichier) return res.status(404).json({ message: 'Cette entrée ne contient aucun fichier joint (commentaire uniquement).' });

  if (req.user.role === 'rmo' && justif.PlanAction.rmo_id !== req.user.id) {
    return res.status(403).json({ message: 'Accès non autorisé.' });
  }

  const filePath = path.join(__dirname, '..', '..', 'uploads', 'justificatifs', justif.chemin_fichier);
  res.download(filePath, justif.nom_fichier);
});

// --- EXPORT EXCEL de la liste des plans d'action ---
router.get('/export/excel', async (req, res) => {
  const where = {};
  if (req.user.role === 'rmo') where.rmo_id = req.user.id;

  const plans = await PlanAction.findAll({
    where,
    include: [
      { model: Controle, as: 'controle', attributes: ['code'] },
      { model: User, as: 'rmo', attributes: ['nom', 'prenom'] },
    ],
    order: [['date_echeance', 'ASC']],
  });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Plans d'action");
  sheet.columns = [
    { header: 'Code', key: 'code', width: 12 },
    { header: 'Code contrôle', key: 'controle_code', width: 14 },
    { header: 'Recommandation', key: 'recommandation', width: 45 },
    { header: 'RMO', key: 'rmo', width: 22 },
    { header: "Date d'échéance", key: 'date_echeance', width: 16 },
    { header: 'Statut', key: 'statut', width: 20 },
    { header: 'Commentaire refus', key: 'commentaire_refus', width: 30 },
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9B48F' } };

  plans.map(withStatutAffiche).forEach((p) => {
    sheet.addRow({
      code: p.code,
      controle_code: p.controle?.code,
      recommandation: p.recommandation,
      rmo: p.rmo ? `${p.rmo.prenom} ${p.rmo.nom}` : '',
      date_echeance: p.date_echeance,
      statut: p.statut_affiche,
      commentaire_refus: p.commentaire_refus,
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=liste_plans_action.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

module.exports = router;
