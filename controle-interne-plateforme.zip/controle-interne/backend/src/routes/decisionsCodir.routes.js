const express = require('express');
const path = require('path');
const ExcelJS = require('exceljs');
const { Op } = require('sequelize');
const { DecisionCodir, User } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadExcel, uploadJustificatif } = require('../config/upload');
const { notifierNouvelleDecisionCodir } = require('../config/mailer');

const router = express.Router();
router.use(authenticate);

const GERANTS = ['admin', 'controleur', 'codir']; // profils "gouvernance" : gèrent le module
// Le RMO a accès en lecture/mise à jour restreinte sur SES propres décisions envoyées uniquement.

function genererCode() {
  const annee = new Date().getFullYear();
  return `DC-${annee}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

function normaliser(txt) {
  return (txt || '').toString().trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function withStatutAffiche(decision) {
  const d = decision.toJSON ? decision.toJSON() : decision;
  const dejaFinal = ['applique', 'abandonne'].includes(d.statut);
  const estEnRetard = !dejaFinal && d.date_echeance && new Date(d.date_echeance) < new Date();
  const enCoursOuRefuse = ['en_cours', 'refuse'].includes(d.statut);
  d.statut_affiche = estEnRetard && enCoursOuRefuse ? 'echu' : d.statut;
  return d;
}

// --- Liste ---
// Gérants (admin/controleur/codir) : voient tout (brouillons + envoyées).
// RMO : voient uniquement leurs décisions déjà envoyées.
router.get('/', async (req, res) => {
  const { statut, responsable_id } = req.query;
  const where = {};
  if (statut) where.statut = statut;

  if (req.user.role === 'rmo') {
    where.responsable_id = req.user.id;
    where.statut_envoi = 'envoyee';
  } else if (responsable_id) {
    where.responsable_id = responsable_id;
  }

  const decisions = await DecisionCodir.findAll({
    where,
    include: [
      { model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom', 'role'] },
      { model: User, as: 'createur', attributes: ['id', 'nom', 'prenom'] },
    ],
    order: [['createdAt', 'DESC']],
  });
  res.json(decisions.map(withStatutAffiche));
});

// --- Création manuelle (gérants) ---
router.post('/', authorize(...GERANTS), async (req, res) => {
  try {
    const { intitule, responsable_id, date_echeance, date_decision, commentaire, numero } = req.body;
    if (!intitule || !responsable_id || !date_echeance) {
      return res.status(400).json({ message: 'Intitulé, responsable et échéance sont obligatoires.' });
    }

    const responsable = await User.findByPk(responsable_id);
    if (!responsable || !['controleur', 'admin', 'rmo'].includes(responsable.role)) {
      return res.status(400).json({ message: 'Responsable invalide.' });
    }

    let code = genererCode();
    while (await DecisionCodir.findOne({ where: { code } })) code = genererCode();

    const decision = await DecisionCodir.create({
      code,
      numero: numero || null,
      intitule,
      responsable_id,
      cree_par_id: req.user.id,
      date_echeance,
      date_decision: date_decision || null,
      commentaire: commentaire || null,
      statut: 'en_cours',
      statut_envoi: 'envoyee', // création manuelle unitaire = envoyée immédiatement, comme avant
    });

    if (responsable.email) {
      notifierNouvelleDecisionCodir({
        responsableEmail: responsable.email,
        responsableNom: `${responsable.prenom} ${responsable.nom}`,
        decisionCode: decision.code,
        numero: decision.numero,
        intitule: decision.intitule,
        dateEcheance: decision.date_echeance,
      });
    }

    res.status(201).json(decision);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la création de la décision CODIR.' });
  }
});

// --- Import Excel en masse (format CODIR : N° | ACTIONS | RMO | ECHEANCES | STATUT DECISION | OBSERVATIONS) ---
// Crée des décisions en BROUILLON : aucun email n'est envoyé, aucun RMO n'y a accès tant
// qu'un gérant n'a pas assigné un responsable réel puis cliqué sur "Envoyer".
router.post('/import', authorize(...GERANTS), uploadExcel.single('fichier'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier Excel fourni.' });

  try {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(req.file.buffer);

    console.log(`[DEBUG import CODIR] Fichier reçu, ${workbook.worksheets.length} feuille(s) : ${workbook.worksheets.map((w) => `"${w.name}" (${w.rowCount} lignes)`).join(', ')}`);

    // Cherche la ligne d'en-tête (contient "ACTIONS") en parcourant TOUTES les feuilles du
    // classeur (pas seulement la première), pour ignorer d'éventuelles feuilles vides en tête.
    let sheet = null;
    let ligneEntete = null;
    for (const ws of workbook.worksheets) {
      for (let i = 1; i <= Math.min(8, ws.rowCount); i++) {
        const texteLigne = ws.getRow(i).values.map((v) => normaliser(v)).join(' ');
        if (texteLigne.includes('actions')) { sheet = ws; ligneEntete = i; break; }
      }
      if (sheet) break;
    }

    if (!sheet) {
      const apercu = workbook.worksheets.map((ws) => {
        const l1 = ws.getRow(1).values.map((v) => normaliser(v)).join(' | ');
        return `"${ws.name}" ligne 1 = "${l1}"`;
      }).join(' — ');
      console.log(`[DEBUG import CODIR] Colonne ACTIONS introuvable. Aperçu : ${apercu}`);
      return res.status(400).json({
        message: `Colonne "ACTIONS" introuvable dans le fichier. Vérifiez qu'une ligne d'en-tête contient bien le mot "ACTIONS". Aperçu de la 1ère ligne de chaque feuille : ${apercu}`,
      });
    }

    console.log(`[DEBUG import CODIR] En-tête trouvé feuille "${sheet.name}", ligne ${ligneEntete}`);

    const headerMap = {};
    sheet.getRow(ligneEntete).eachCell((cell, colNumber) => { headerMap[colNumber] = normaliser(cell.text); });
    console.log(`[DEBUG import CODIR] headerMap =`, headerMap);

    function trouverColonne(motsClefs) {
      for (const [col, texte] of Object.entries(headerMap)) {
        if (motsClefs.includes(texte)) return Number(col);
      }
      for (const [col, texte] of Object.entries(headerMap)) {
        if (motsClefs.some((m) => texte.includes(m))) return Number(col);
      }
      return null;
    }

    const colNumero = trouverColonne(['n', 'no', 'n°']);
    const colActions = trouverColonne(['actions']);
    const colRmo = trouverColonne(['rmo']);
    const colEcheances = trouverColonne(['echeances', 'echeance']);
    const colStatut = trouverColonne(['statut decision', 'statut']);
    const colObservations = trouverColonne(['observations', 'observation']);
    console.log(`[DEBUG import CODIR] colonnes : numero=${colNumero} actions=${colActions} rmo=${colRmo} echeances=${colEcheances} statut=${colStatut} observations=${colObservations}, lignes de données de ${ligneEntete + 1} à ${sheet.rowCount}`);

    const lire = (row, col) => (col ? row.getCell(col).text?.trim() : undefined);

    let crees = 0;
    const erreurs = [];

    for (let i = ligneEntete + 1; i <= sheet.rowCount; i++) {
      const row = sheet.getRow(i);
      const intitule = lire(row, colActions);
      if (!intitule) {
        const brut = row.values.map((v) => normaliser(v)).join(' | ');
        if (brut.trim()) console.log(`[DEBUG import CODIR] Ligne ${i} ignorée (pas d'intitulé lu en colonne ${colActions}) — contenu brut : "${brut}"`);
        continue;
      }

      const echeanceRaw = lire(row, colEcheances);
      let date_echeance = null;
      if (echeanceRaw) {
        if (/immediat/i.test(normaliser(echeanceRaw))) {
          date_echeance = new Date().toISOString().slice(0, 10);
        } else {
          const parsed = new Date(echeanceRaw);
          if (!isNaN(parsed.getTime())) date_echeance = parsed.toISOString().slice(0, 10);
        }
      }

      let code = genererCode();
      while (await DecisionCodir.findOne({ where: { code } })) code = genererCode();

      try {
        await DecisionCodir.create({
          code,
          numero: lire(row, colNumero) || null,
          intitule,
          rmo_suggere: lire(row, colRmo) || null,
          date_echeance,
          responsable_id: null,
          cree_par_id: req.user.id,
          statut: 'en_cours',
          statut_envoi: 'brouillon',
          commentaire: lire(row, colObservations) || null,
        });
        crees++;
      } catch (e) {
        erreurs.push(`Ligne ${i} : ${e.message}`);
      }
    }

    res.json({ message: `${crees} décision(s) importée(s) en brouillon. Assignez un RMO puis envoyez chaque décision.`, crees, erreurs });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la lecture du fichier Excel.' });
  }
});

// --- Assigner un responsable réel à une décision en brouillon ---
router.put('/:id/assigner', authorize(...GERANTS), async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });

  const { responsable_id, date_echeance } = req.body;
  if (!responsable_id) return res.status(400).json({ message: 'Responsable requis.' });

  const responsable = await User.findByPk(responsable_id);
  if (!responsable || !['controleur', 'admin', 'rmo'].includes(responsable.role)) {
    return res.status(400).json({ message: 'Responsable invalide.' });
  }

  decision.responsable_id = responsable_id;
  if (date_echeance) decision.date_echeance = date_echeance;
  await decision.save();
  res.json(decision);
});

// --- Envoyer une décision (rend visible au RMO + email individuel) ---
router.post('/:id/envoyer', authorize(...GERANTS), async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id, {
    include: [{ model: User, as: 'responsable' }],
  });
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });
  if (!decision.responsable_id) return res.status(400).json({ message: 'Assignez d\'abord un responsable avant d\'envoyer.' });
  if (!decision.date_echeance) return res.status(400).json({ message: 'Une date d\'échéance est requise avant l\'envoi.' });
  if (decision.statut_envoi === 'envoyee') return res.status(400).json({ message: 'Cette décision a déjà été envoyée.' });

  decision.statut_envoi = 'envoyee';
  await decision.save();

  if (decision.responsable?.email) {
    await notifierNouvelleDecisionCodir({
      responsableEmail: decision.responsable.email,
      responsableNom: `${decision.responsable.prenom} ${decision.responsable.nom}`,
      decisionCode: decision.code,
      numero: decision.numero,
      intitule: decision.intitule,
      dateEcheance: decision.date_echeance,
    });
  }

  res.json(decision);
});

// --- Envoi groupé de tous les brouillons déjà assignés et complets ---
router.post('/envoyer-tout', authorize(...GERANTS), async (req, res) => {
  const brouillons = await DecisionCodir.findAll({
    where: { statut_envoi: 'brouillon', responsable_id: { [Op.ne]: null }, date_echeance: { [Op.ne]: null } },
    include: [{ model: User, as: 'responsable' }],
  });

  let envoyees = 0;
  for (const decision of brouillons) {
    decision.statut_envoi = 'envoyee';
    await decision.save();
    if (decision.responsable?.email) {
      await notifierNouvelleDecisionCodir({
        responsableEmail: decision.responsable.email,
        responsableNom: `${decision.responsable.prenom} ${decision.responsable.nom}`,
        decisionCode: decision.code,
        numero: decision.numero,
        intitule: decision.intitule,
        dateEcheance: decision.date_echeance,
      });
    }
    envoyees++;
  }

  res.json({ message: `${envoyees} décision(s) envoyée(s).`, envoyees });
});

// --- Réponse du RMO : commentaire + statut, avec pièce jointe FACULTATIVE ---
// Au moins un commentaire, un fichier, ou un changement de statut doit être fourni.
router.post('/:id/reponse', authorize('rmo'), uploadJustificatif.single('fichier'), async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });
  if (decision.responsable_id !== req.user.id || decision.statut_envoi !== 'envoyee') {
    return res.status(403).json({ message: 'Accès non autorisé à cette décision.' });
  }

  const { commentaire, statut } = req.body;
  if (!commentaire?.trim() && !req.file && !statut) {
    return res.status(400).json({ message: 'Ajoutez au moins un commentaire, un fichier, ou un changement de statut.' });
  }

  if (commentaire !== undefined) decision.commentaire = commentaire;
  if (statut) { decision.statut = statut; if (statut === 'en_cours') decision.notifie_retard = false; }
  if (req.file) {
    decision.fichier_nom = req.file.originalname;
    decision.fichier_chemin = req.file.filename;
  }
  await decision.save();
  res.json(decision);
});

// --- Téléchargement de la pièce jointe RMO ---
router.get('/:id/fichier/download', async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });
  if (!decision.fichier_chemin) return res.status(404).json({ message: 'Aucun fichier joint sur cette décision.' });
  if (req.user.role === 'rmo' && decision.responsable_id !== req.user.id) {
    return res.status(403).json({ message: 'Accès non autorisé.' });
  }
  const filePath = path.join(__dirname, '..', '..', 'uploads', 'justificatifs', decision.fichier_chemin);
  res.download(filePath, decision.fichier_nom);
});

// --- Modification ---
// Gérants : tout modifiable. RMO : uniquement statut + commentaire (sans fichier), via cette
// route JSON simple ; pour joindre un fichier, utiliser POST /:id/reponse ci-dessus.
router.put('/:id', async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });

  if (req.user.role === 'rmo') {
    if (decision.responsable_id !== req.user.id || decision.statut_envoi !== 'envoyee') {
      return res.status(403).json({ message: 'Accès non autorisé à cette décision.' });
    }
    const { statut, commentaire } = req.body;
    if (statut) decision.statut = statut;
    if (commentaire !== undefined) decision.commentaire = commentaire;
    await decision.save();
    return res.json(decision);
  }

  if (!GERANTS.includes(req.user.role)) {
    return res.status(403).json({ message: "Vous n'avez pas accès à ce module." });
  }

  const { intitule, responsable_id, date_echeance, statut, commentaire, numero } = req.body;
  if (intitule) decision.intitule = intitule;
  if (responsable_id) decision.responsable_id = responsable_id;
  if (numero !== undefined) decision.numero = numero;
  if (date_echeance) { decision.date_echeance = date_echeance; decision.notifie_retard = false; }
  if (statut) { decision.statut = statut; if (statut === 'en_cours') decision.notifie_retard = false; }
  if (commentaire !== undefined) decision.commentaire = commentaire;
  await decision.save();

  res.json(decision);
});

// --- Suppression (gérants uniquement) ---
router.delete('/:id', authorize(...GERANTS), async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });
  await decision.destroy();
  res.json({ message: 'Décision CODIR supprimée.' });
});

// --- Export Excel (gérants) ---
router.get('/export/excel', authorize(...GERANTS), async (req, res) => {
  const decisions = await DecisionCodir.findAll({
    include: [{ model: User, as: 'responsable', attributes: ['nom', 'prenom'] }],
    order: [['createdAt', 'DESC']],
  });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Décisions CODIR');
  sheet.columns = [
    { header: 'N°', key: 'numero', width: 8 },
    { header: 'Code', key: 'code', width: 14 },
    { header: 'Actions', key: 'intitule', width: 50 },
    { header: 'Responsable', key: 'responsable', width: 22 },
    { header: 'Échéance', key: 'date_echeance', width: 14 },
    { header: 'Statut décision', key: 'statut', width: 16 },
    { header: 'Observations', key: 'commentaire', width: 35 },
    { header: 'Envoi', key: 'statut_envoi', width: 12 },
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E2F3' } };

  decisions.map(withStatutAffiche).forEach((d) => {
    sheet.addRow({
      numero: d.numero,
      code: d.code,
      intitule: d.intitule,
      responsable: d.responsable ? `${d.responsable.prenom} ${d.responsable.nom}` : '',
      date_echeance: d.date_echeance,
      statut: d.statut_affiche,
      commentaire: d.commentaire,
      statut_envoi: d.statut_envoi,
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=decisions_codir.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

module.exports = router;
