const express = require('express');
const ExcelJS = require('exceljs');
const { DecisionCodir, User } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);
// Réservé aux contrôleurs et admin : les RMO n'ont pas accès à ce suivi de gouvernance.
router.use(authorize('admin', 'controleur'));

function genererCode() {
  const annee = new Date().getFullYear();
  return `DC-${annee}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

function withStatutAffiche(decision) {
  const d = decision.toJSON ? decision.toJSON() : decision;
  const dejaFinal = ['applique', 'abandonne'].includes(d.statut);
  const estEnRetard = !dejaFinal && d.date_echeance && new Date(d.date_echeance) < new Date();
  const enCoursOuRefuse = ['en_cours', 'refuse'].includes(d.statut);
  d.statut_affiche = estEnRetard && enCoursOuRefuse ? 'echu' : d.statut;
  return d;
}

// --- Liste ---
router.get('/', async (req, res) => {
  const { statut, responsable_id } = req.query;
  const where = {};
  if (statut) where.statut = statut;
  if (responsable_id) where.responsable_id = responsable_id;

  const decisions = await DecisionCodir.findAll({
    where,
    include: [
      { model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom'] },
      { model: User, as: 'createur', attributes: ['id', 'nom', 'prenom'] },
    ],
    order: [['date_echeance', 'ASC']],
  });
  res.json(decisions.map(withStatutAffiche));
});

// --- Création (le créateur a le même profil que le contrôleur : admin ou controleur) ---
router.post('/', async (req, res) => {
  try {
    const { intitule, responsable_id, date_echeance, date_decision, commentaire } = req.body;
    if (!intitule || !responsable_id || !date_echeance) {
      return res.status(400).json({ message: 'Intitulé, responsable et échéance sont obligatoires.' });
    }

    const responsable = await User.findByPk(responsable_id);
    if (!responsable || !['controleur', 'admin'].includes(responsable.role)) {
      return res.status(400).json({ message: 'Le responsable doit être un contrôleur.' });
    }

    let code = genererCode();
    while (await DecisionCodir.findOne({ where: { code } })) code = genererCode();

    const decision = await DecisionCodir.create({
      code,
      intitule,
      responsable_id,
      cree_par_id: req.user.id,
      date_echeance,
      date_decision: date_decision || null,
      commentaire: commentaire || null,
      statut: 'en_cours',
    });

    res.status(201).json(decision);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la création de la décision CODIR.' });
  }
});

// --- Modification du statut / des champs ---
router.put('/:id', async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });

  const { intitule, responsable_id, date_echeance, statut, commentaire } = req.body;
  if (intitule) decision.intitule = intitule;
  if (responsable_id) decision.responsable_id = responsable_id;
  if (date_echeance) { decision.date_echeance = date_echeance; decision.notifie_retard = false; }
  if (statut) { decision.statut = statut; if (statut === 'en_cours') decision.notifie_retard = false; }
  if (commentaire !== undefined) decision.commentaire = commentaire;
  await decision.save();

  res.json(decision);
});

// --- Suppression ---
router.delete('/:id', async (req, res) => {
  const decision = await DecisionCodir.findByPk(req.params.id);
  if (!decision) return res.status(404).json({ message: 'Décision CODIR introuvable.' });
  await decision.destroy();
  res.json({ message: 'Décision CODIR supprimée.' });
});

// --- Export Excel ---
router.get('/export/excel', async (req, res) => {
  const decisions = await DecisionCodir.findAll({
    include: [{ model: User, as: 'responsable', attributes: ['nom', 'prenom'] }],
    order: [['date_echeance', 'ASC']],
  });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Décisions CODIR');
  sheet.columns = [
    { header: 'Code', key: 'code', width: 14 },
    { header: 'Intitulé', key: 'intitule', width: 50 },
    { header: 'Responsable', key: 'responsable', width: 22 },
    { header: "Date d'échéance", key: 'date_echeance', width: 16 },
    { header: 'Statut', key: 'statut', width: 16 },
  ];
  sheet.getRow(1).font = { bold: true };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFD9E2F3' } };

  decisions.map(withStatutAffiche).forEach((d) => {
    sheet.addRow({
      code: d.code,
      intitule: d.intitule,
      responsable: d.responsable ? `${d.responsable.prenom} ${d.responsable.nom}` : '',
      date_echeance: d.date_echeance,
      statut: d.statut_affiche,
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=decisions_codir.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

module.exports = router;
