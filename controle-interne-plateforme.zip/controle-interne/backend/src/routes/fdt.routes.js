const express = require('express');
const path = require('path');
const { FeuilleTravail, Controle, User } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadFDT } = require('../config/upload');
const { periodeCourante, libellePeriode } = require('../config/periodes');

const router = express.Router();
router.use(authenticate);

function genererCodeFdt() {
  const annee = new Date().getFullYear();
  return `FDT-${annee}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

// --- Liste des FDT (avec filtre par code de contrôle) ---
router.get('/', async (req, res) => {
  const { controle_code } = req.query;
  const include = [
    { model: User, as: 'auteur', attributes: ['id', 'nom', 'prenom'] },
    { model: Controle, as: 'controle', attributes: ['id', 'code', 'processus', 'periodicite'] },
  ];
  if (controle_code) include[1].where = { code: controle_code };

  const fdts = await FeuilleTravail.findAll({ include, order: [['createdAt', 'DESC']] });
  res.json(fdts.map((f) => ({ ...f.toJSON(), periode_libelle: libellePeriode(f.periode_label) })));
});

// --- Upload d'une FDT (PDF signé) associée à un code de contrôle ---
// C'est cette action qui fait passer le contrôle à 100% pour la période en cours.
router.post('/', authorize('admin', 'controleur'), uploadFDT.single('fichier'), async (req, res) => {
  const { controle_code } = req.body;
  if (!controle_code) return res.status(400).json({ message: 'Le code de contrôle est obligatoire.' });
  if (!req.file) return res.status(400).json({ message: 'Le fichier PDF de la FDT est obligatoire.' });

  const controle = await Controle.findOne({ where: { code: controle_code } });
  if (!controle) return res.status(404).json({ message: 'Code de contrôle introuvable.' });

  const periode_label = periodeCourante(controle.periodicite);

  const existante = await FeuilleTravail.findOne({ where: { controle_id: controle.id, periode_label } });
  if (existante) {
    return res.status(409).json({
      message: `Une FDT a déjà été déposée pour ${controle.code} sur la période ${libellePeriode(periode_label)}. Supprimez-la d'abord si vous souhaitez la remplacer.`,
    });
  }

  let code = genererCodeFdt();
  while (await FeuilleTravail.findOne({ where: { code } })) code = genererCodeFdt();

  const fdt = await FeuilleTravail.create({
    code,
    controle_id: controle.id,
    periode_label,
    nom_fichier: req.file.originalname,
    chemin_fichier: req.file.filename,
    uploaded_by: req.user.id,
  });

  res.status(201).json({ ...fdt.toJSON(), periode_libelle: libellePeriode(periode_label) });
});

// --- Téléchargement du PDF d'une FDT ---
router.get('/:id/download', async (req, res) => {
  const fdt = await FeuilleTravail.findByPk(req.params.id);
  if (!fdt) return res.status(404).json({ message: 'FDT introuvable.' });
  const filePath = path.join(__dirname, '..', '..', 'uploads', 'fdt', fdt.chemin_fichier);
  res.download(filePath, `${fdt.code}.pdf`);
});

// --- Suppression d'une FDT (admin + controleur) ---
router.delete('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const fdt = await FeuilleTravail.findByPk(req.params.id);
  if (!fdt) return res.status(404).json({ message: 'FDT introuvable.' });
  await fdt.destroy();
  res.json({ message: 'FDT supprimée.' });
});

module.exports = router;
