const express = require('express');
const path = require('path');
const { Op } = require('sequelize');
const { FeuilleTravail, FdtControle, Controle, User } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadFDT } = require('../config/upload');
const { periodeCourante, libellePeriode } = require('../config/periodes');

const router = express.Router();
router.use(authenticate);
router.use(authorize('admin', 'controleur')); // les RMO n'ont pas accès aux FDT

function genererCodeFdt() {
  const annee = new Date().getFullYear();
  return `FDT-${annee}-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
}

function formaterFdt(fdt) {
  const j = fdt.toJSON();
  j.controles = (j.liens || []).map((l) => ({
    id: l.controle?.id,
    code: l.controle?.code,
    processus: l.controle?.processus,
    periode_label: l.periode_label,
    periode_libelle: libellePeriode(l.periode_label),
  }));
  delete j.liens;
  return j;
}

// --- Liste des FDT (avec filtre optionnel par code de contrôle) ---
router.get('/', async (req, res) => {
  const { controle_code } = req.query;

  const includeLiens = {
    model: FdtControle,
    as: 'liens',
    include: [{ model: Controle, as: 'controle', attributes: ['id', 'code', 'processus', 'periodicite'] }],
  };

  let fdts = await FeuilleTravail.findAll({
    include: [{ model: User, as: 'auteur', attributes: ['id', 'nom', 'prenom'] }, includeLiens],
    order: [['createdAt', 'DESC']],
  });

  let resultats = fdts.map(formaterFdt);

  if (controle_code) {
    resultats = resultats.filter((f) => f.controles.some((c) => c.code === controle_code));
  }

  res.json(resultats);
});

// --- Dépôt d'une FDT (PDF signé) — peut couvrir plusieurs codes de contrôle à la fois ---
router.post('/', authorize('admin', 'controleur'), uploadFDT.single('fichier'), async (req, res) => {
  const { controle_codes } = req.body;
  if (!controle_codes || !controle_codes.trim()) {
    return res.status(400).json({ message: 'Indiquez au moins un code de contrôle.' });
  }
  if (!req.file) return res.status(400).json({ message: 'Le fichier PDF de la FDT est obligatoire.' });

  const codes = [...new Set(controle_codes.split(',').map((c) => c.trim()).filter(Boolean))];

  const controles = await Controle.findAll({ where: { code: { [Op.in]: codes } } });
  let codesTrouves = new Set(controles.map((c) => c.code));
  let introuvables = codes.filter((c) => !codesTrouves.has(c));

  // Deuxième passe insensible à la casse pour les codes non trouvés à l'identique
  if (introuvables.length > 0) {
    for (const code of [...introuvables]) {
      const trouve = await Controle.findOne({ where: { code: { [Op.iLike]: code } } });
      if (trouve && !controles.some((c) => c.id === trouve.id)) {
        controles.push(trouve);
        introuvables = introuvables.filter((c) => c !== code);
      }
    }
  }

  if (introuvables.length > 0) {
    return res.status(404).json({ message: `Code(s) de contrôle introuvable(s) : ${introuvables.join(', ')}` });
  }

  let code = genererCodeFdt();
  while (await FeuilleTravail.findOne({ where: { code } })) code = genererCodeFdt();

  const fdt = await FeuilleTravail.create({
    code,
    nom_fichier: req.file.originalname,
    chemin_fichier: req.file.filename,
    uploaded_by: req.user.id,
  });

  const resultats = [];
  for (const controle of controles) {
    const periode_label = periodeCourante(controle.periodicite);
    const existant = await FdtControle.findOne({ where: { controle_id: controle.id, periode_label } });
    if (existant) {
      resultats.push({ code: controle.code, statut: 'deja_couvert', periode: libellePeriode(periode_label) });
      continue;
    }
    await FdtControle.create({ fdt_id: fdt.id, controle_id: controle.id, periode_label });
    resultats.push({ code: controle.code, statut: 'ajoute', periode: libellePeriode(periode_label) });
  }

  const fdtComplet = await FeuilleTravail.findByPk(fdt.id, {
    include: [
      { model: User, as: 'auteur', attributes: ['id', 'nom', 'prenom'] },
      { model: FdtControle, as: 'liens', include: [{ model: Controle, as: 'controle', attributes: ['id', 'code', 'processus', 'periodicite'] }] },
    ],
  });

  res.status(201).json({ ...formaterFdt(fdtComplet), resultats });
});

// --- Téléchargement du PDF d'une FDT ---
router.get('/:id/download', async (req, res) => {
  const fdt = await FeuilleTravail.findByPk(req.params.id);
  if (!fdt) return res.status(404).json({ message: 'FDT introuvable.' });
  const filePath = path.join(__dirname, '..', '..', 'uploads', 'fdt', fdt.chemin_fichier);
  res.download(filePath, `${fdt.code}.pdf`);
});

// --- Suppression d'une FDT (admin + controleur) ---
router.delete('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const fdt = await FeuilleTravail.findByPk(req.params.id);
  if (!fdt) return res.status(404).json({ message: 'FDT introuvable.' });
  await fdt.destroy();
  res.json({ message: 'FDT supprimée.' });
});

module.exports = router;
