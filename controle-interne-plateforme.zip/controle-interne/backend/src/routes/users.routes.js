const express = require('express');
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');

const router = express.Router();
router.use(authenticate);

// Liste des utilisateurs - admin et controleur peuvent consulter (lecture seule pour controleur)
router.get('/', authorize('admin', 'controleur'), async (req, res) => {
  const users = await User.findAll({
    attributes: { exclude: ['password_hash'] },
    order: [['nom', 'ASC']],
  });
  res.json(users);
});

// Création d'un utilisateur - ADMIN UNIQUEMENT
router.post('/', authorize('admin'), async (req, res) => {
  try {
    const { nom, prenom, email, password, role, entite } = req.body;
    if (!nom || !prenom || !email || !password || !role) {
      return res.status(400).json({ message: 'Tous les champs obligatoires doivent être renseignés.' });
    }
    if (!['admin', 'controleur', 'rmo'].includes(role)) {
      return res.status(400).json({ message: 'Rôle invalide.' });
    }
    const password_hash = await bcrypt.hash(password, 10);
    const user = await User.create({ nom, prenom, email, password_hash, role, entite });
    const { password_hash: _, ...safeUser } = user.toJSON();
    res.status(201).json(safeUser);
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ message: 'Cet email est déjà utilisé.' });
    }
    console.error(err);
    res.status(500).json({ message: 'Erreur serveur lors de la création.' });
  }
});

// Modification (rôle, entité, statut actif) - ADMIN UNIQUEMENT
router.put('/:id', authorize('admin'), async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable.' });

    const { nom, prenom, role, entite, actif, password } = req.body;
    if (nom) user.nom = nom;
    if (prenom) user.prenom = prenom;
    if (role) user.role = role;
    if (entite !== undefined) user.entite = entite;
    if (actif !== undefined) user.actif = actif;
    if (password) user.password_hash = await bcrypt.hash(password, 10);

    await user.save();
    const { password_hash: _, ...safeUser } = user.toJSON();
    res.json(safeUser);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur serveur lors de la modification.' });
  }
});

// Suppression - ADMIN UNIQUEMENT
router.delete('/:id', authorize('admin'), async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable.' });
    if (req.user.id === user.id) {
      return res.status(400).json({ message: 'Vous ne pouvez pas supprimer votre propre compte.' });
    }
    await user.destroy();
    res.json({ message: 'Utilisateur supprimé.' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Erreur serveur lors de la suppression.' });
  }
});

module.exports = router;
