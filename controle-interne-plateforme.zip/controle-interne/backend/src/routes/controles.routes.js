const express = require('express');
const ExcelJS = require('exceljs');
const { Controle, User, FdtControle } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadExcel } = require('../config/upload');
const { periodeCourante, libellePeriode } = require('../config/periodes');

const router = express.Router();
router.use(authenticate);

const PERIODICITES = ['Hebdomadaire', 'Mensuelle', 'Trimestrielle', 'Semestrielle', 'Annuelle'];

// Ajoute le taux de conformité calculé pour la période en cours (100% si une FDT couvre ce contrôle, sinon 0%)
async function avecConformite(controle) {
  const c = controle.toJSON ? controle.toJSON() : controle;
  const periode_label = periodeCourante(c.periodicite);
  const lien = await FdtControle.findOne({ where: { controle_id: c.id, periode_label } });
  c.periode_courante = libellePeriode(periode_label);
  c.taux_conformite = lien ? 100 : 0;
  c.fdt_periode_courante_id = lien ? lien.fdt_id : null;
  return c;
}

// --- Liste des contrôles (tous les rôles connectés peuvent consulter) ---
router.get('/', async (req, res) => {
  const { periodicite, processus, actif } = req.query;
  const where = {};
  if (periodicite) where.periodicite = periodicite;
  if (processus) where.processus = processus;
  if (actif !== undefined) where.actif = actif === 'true';

  const controles = await Controle.findAll({
    where,
    include: [{ model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom'] }],
    order: [['code', 'ASC']],
  });
  const resultats = await Promise.all(controles.map(avecConformite));
  res.json(resultats);
});

// --- Détail d'un contrôle ---
router.get('/:id', async (req, res) => {
  const controle = await Controle.findByPk(req.params.id, {
    include: [{ model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom'] }],
  });
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  res.json(await avecConformite(controle));
});

// --- Création manuelle d'un contrôle (admin + controleur) ---
router.post('/', authorize('admin', 'controleur'), async (req, res) => {
  try {
    const controle = await Controle.create(req.body);
    res.status(201).json(controle);
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ message: 'Ce code de contrôle existe déjà.' });
    }
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la création du contrôle.' });
  }
});

// --- Modification (admin + controleur) ---
router.put('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const controle = await Controle.findByPk(req.params.id);
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  await controle.update(req.body);
  res.json(controle);
});

// --- Suppression (admin + controleur) ---
router.delete('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const controle = await Controle.findByPk(req.params.id);
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  await controle.destroy();
  res.json({ message: 'Contrôle supprimé.' });
});

// --- EXPORT EXCEL : liste des contrôles actuels (colonnes du "Programme de contrôle") ---
router.get('/export/excel', async (req, res) => {
  const controles = await Controle.findAll({
    include: [{ model: User, as: 'responsable', attributes: ['nom', 'prenom'] }],
    order: [['code', 'ASC']],
  });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Programme de contrôle');

  sheet.columns = [
    { header: 'Code', key: 'code', width: 12 },
    { header: 'Processus', key: 'processus', width: 22 },
    { header: 'Activité', key: 'activite', width: 26 },
    { header: 'Risques', key: 'risques', width: 30 },
    { header: 'Contrôles', key: 'description', width: 45 },
    { header: 'Sources', key: 'sources', width: 20 },
    { header: 'Support requis', key: 'support_requis', width: 30 },
    { header: 'Périodicité', key: 'periodicite', width: 14 },
    { header: 'Dates', key: 'dates', width: 22 },
    { header: 'Responsable', key: 'responsable', width: 22 },
    { header: 'Taux conformité (%)', key: 'taux_conformite', width: 16 },
    { header: 'Actif', key: 'actif', width: 10 },
  ];
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4BACC6' } };

  controles.forEach((c) => {
    sheet.addRow({
      code: c.code,
      processus: c.processus,
      activite: c.activite,
      risques: c.risques,
      description: c.description,
      sources: c.sources,
      support_requis: c.support_requis,
      periodicite: c.periodicite,
      dates: c.dates,
      responsable: c.responsable ? `${c.responsable.prenom} ${c.responsable.nom}` : '',
      taux_conformite: c.taux_conformite,
      actif: c.actif ? 'Oui' : 'Non',
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=programme_controle.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

// --- IMPORT EXCEL : ajout / mise à jour de contrôles (admin + controleur) ---
// Colonnes attendues (ligne d'en-tête ignorée) :
// Code | Processus | Activité | Risques | Contrôles | Sources | Support requis | Périodicité | Dates
router.post('/import/excel', authorize('admin', 'controleur'), uploadExcel.single('fichier'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier Excel fourni.' });

  try {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(req.file.buffer);
    const sheet = workbook.worksheets[0];

    const results = { crees: 0, mis_a_jour: 0, erreurs: [] };

    for (let i = 2; i <= sheet.rowCount; i++) {
      const row = sheet.getRow(i);
      const code = row.getCell(1).text?.trim();
      if (!code) continue;

      const periodiciteRaw = row.getCell(8).text?.trim();
      const periodicite = PERIODICITES.find(
        (p) => p.toLowerCase() === (periodiciteRaw || '').toLowerCase()
      ) || 'Mensuelle';

      const data = {
        code,
        processus: row.getCell(2).text?.trim(),
        activite: row.getCell(3).text?.trim(),
        risques: row.getCell(4).text?.trim(),
        description: row.getCell(5).text?.trim(),
        sources: row.getCell(6).text?.trim(),
        support_requis: row.getCell(7).text?.trim(),
        periodicite,
        dates: row.getCell(9).text?.trim(),
      };

      try {
        const [controle, created] = await Controle.findOrCreate({
          where: { code },
          defaults: data,
        });
        if (!created) {
          await controle.update(data);
          results.mis_a_jour++;
        } else {
          results.crees++;
        }
      } catch (e) {
        results.erreurs.push(`Ligne ${i} (${code}) : ${e.message}`);
      }
    }

    res.json({ message: 'Import terminé.', ...results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Erreur lors de la lecture du fichier Excel. Vérifiez le format." });
  }
});

module.exports = router;
