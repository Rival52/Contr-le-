const express = require('express');
const ExcelJS = require('exceljs');
const { Controle, User, FdtControle } = require('../models');
const { authenticate, authorize } = require('../middleware/auth');
const { uploadExcel } = require('../config/upload');
const { periodeCourante, libellePeriode } = require('../config/periodes');

const router = express.Router();
router.use(authenticate);
router.use(authorize('admin', 'controleur')); // les RMO n'ont pas accès au programme de contrôle

const PERIODICITES = ['Hebdomadaire', 'Mensuelle', 'Trimestrielle', 'Semestrielle', 'Annuelle'];

// Le fichier source peut utiliser la forme masculine ("Mensuel", "Trimestriel"...) ou
// féminine ("Mensuelle", "Trimestrielle"...) selon qui l'a rempli. On accepte les deux.
const ALIAS_PERIODICITE = {
  hebdomadaire: 'Hebdomadaire', hebdo: 'Hebdomadaire',
  mensuel: 'Mensuelle', mensuelle: 'Mensuelle',
  trimestriel: 'Trimestrielle', trimestrielle: 'Trimestrielle',
  semestriel: 'Semestrielle', semestrielle: 'Semestrielle',
  annuel: 'Annuelle', annuelle: 'Annuelle',
};

// Ajoute le taux de conformité calculé pour la période en cours (100% si une FDT couvre ce contrôle, sinon 0%)
async function avecConformite(controle) {
  const c = controle.toJSON ? controle.toJSON() : controle;
  const periode_label = periodeCourante(c.periodicite);
  const lien = await FdtControle.findOne({ where: { controle_id: c.id, periode_label } });
  c.periode_courante = libellePeriode(periode_label);
  c.taux_conformite = lien ? 100 : 0;
  c.fdt_periode_courante_id = lien ? lien.fdt_id : null;
  return c;
}

// --- Liste des contrôles (tous les rôles connectés peuvent consulter) ---
router.get('/', async (req, res) => {
  const { periodicite, processus, actif } = req.query;
  const where = {};
  if (periodicite) where.periodicite = periodicite;
  if (processus) where.processus = processus;
  if (actif !== undefined) where.actif = actif === 'true';

  const controles = await Controle.findAll({
    where,
    include: [{ model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom'] }],
    order: [['code', 'ASC']],
  });
  const resultats = await Promise.all(controles.map(avecConformite));
  res.json(resultats);
});

// --- Détail d'un contrôle ---
router.get('/:id', async (req, res) => {
  const controle = await Controle.findByPk(req.params.id, {
    include: [{ model: User, as: 'responsable', attributes: ['id', 'nom', 'prenom'] }],
  });
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  res.json(await avecConformite(controle));
});

// --- Création manuelle d'un contrôle (admin + controleur) ---
router.post('/', authorize('admin', 'controleur'), async (req, res) => {
  try {
    const controle = await Controle.create(req.body);
    res.status(201).json(controle);
  } catch (err) {
    if (err.name === 'SequelizeUniqueConstraintError') {
      return res.status(409).json({ message: 'Ce code de contrôle existe déjà.' });
    }
    console.error(err);
    res.status(500).json({ message: 'Erreur lors de la création du contrôle.' });
  }
});

// --- Modification (admin + controleur) ---
router.put('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const controle = await Controle.findByPk(req.params.id);
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  await controle.update(req.body);
  res.json(controle);
});

// --- Suppression (admin + controleur) ---
router.delete('/:id', authorize('admin', 'controleur'), async (req, res) => {
  const controle = await Controle.findByPk(req.params.id);
  if (!controle) return res.status(404).json({ message: 'Contrôle introuvable.' });
  await controle.destroy();
  res.json({ message: 'Contrôle supprimé.' });
});

// --- EXPORT EXCEL : liste des contrôles actuels (colonnes du "Programme de contrôle") ---
router.get('/export/excel', async (req, res) => {
  const controles = await Controle.findAll({
    include: [{ model: User, as: 'responsable', attributes: ['nom', 'prenom'] }],
    order: [['code', 'ASC']],
  });

  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Programme de contrôle');

  sheet.columns = [
    { header: 'Code', key: 'code', width: 12 },
    { header: 'Processus', key: 'processus', width: 22 },
    { header: 'Activité', key: 'activite', width: 26 },
    { header: 'Risques', key: 'risques', width: 30 },
    { header: 'Contrôles', key: 'description', width: 45 },
    { header: 'Sources', key: 'sources', width: 20 },
    { header: 'Support requis', key: 'support_requis', width: 30 },
    { header: 'Périodicité', key: 'periodicite', width: 14 },
    { header: 'Dates', key: 'dates', width: 22 },
    { header: 'Responsable', key: 'responsable', width: 22 },
    { header: 'Taux conformité (%)', key: 'taux_conformite', width: 16 },
    { header: 'Actif', key: 'actif', width: 10 },
  ];
  sheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  sheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4BACC6' } };

  controles.forEach((c) => {
    sheet.addRow({
      code: c.code,
      processus: c.processus,
      activite: c.activite,
      risques: c.risques,
      description: c.description,
      sources: c.sources,
      support_requis: c.support_requis,
      periodicite: c.periodicite,
      dates: c.dates,
      responsable: c.responsable ? `${c.responsable.prenom} ${c.responsable.nom}` : '',
      taux_conformite: c.taux_conformite,
      actif: c.actif ? 'Oui' : 'Non',
    });
  });

  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename=programme_controle.xlsx');
  await workbook.xlsx.write(res);
  res.end();
});

// --- IMPORT EXCEL : ajout / mise à jour de contrôles (admin + controleur) ---
// Colonnes attendues (ligne d'en-tête ignorée) :
// Code | Processus | Activité | Risques | Contrôles | Sources | Support requis | Périodicité | Dates
// --- IMPORT EXCEL : ajout / mise à jour de contrôles (admin + controleur) ---
// La feuille peut avoir ses colonnes dans un ordre différent d'un fichier à l'autre :
// on détecte donc la position de chaque colonne à partir de l'intitulé de son en-tête,
// plutôt que de supposer un ordre fixe (ce qui causait des décalages Code/Processus).
function normaliser(txt) {
  return (txt || '').toString().trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function trouverColonne(headerMap, motsClefs, colonnesUtilisees) {
  // 1) correspondance exacte d'abord
  for (const [col, texte] of Object.entries(headerMap)) {
    if (colonnesUtilisees.has(col)) continue;
    if (motsClefs.includes(texte)) return col;
  }
  // 2) correspondance partielle en repli
  for (const [col, texte] of Object.entries(headerMap)) {
    if (colonnesUtilisees.has(col)) continue;
    if (motsClefs.some((mot) => texte.includes(mot))) return col;
  }
  return null;
}

// Un vrai code de contrôle ressemble à "C31048", "P31001", etc : un préfixe de lettres
// suivi de chiffres. Ça permet de rejeter automatiquement les lignes d'en-tête de
// section/regroupement (ex: noms d'agences ou de processus placés par erreur dans la
// colonne Code) qui n'ont jamais ce format.
const CODE_VALIDE = /^[A-Za-z]{1,4}-?\d{3,8}$/;

router.post('/import/excel', authorize('admin', 'controleur'), uploadExcel.single('fichier'), async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'Aucun fichier Excel fourni.' });

  try {
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(req.file.buffer);

    let sheet = workbook.worksheets.find((ws) => normaliser(ws.name) === 'programme all');
    if (!sheet) sheet = workbook.worksheets.find((ws) => /programme/i.test(ws.name) && /all/i.test(ws.name));
    if (!sheet) sheet = workbook.worksheets.find((ws) => /programme/i.test(ws.name));
    const feuilleUtilisee = sheet ? sheet.name : workbook.worksheets[0]?.name;
    if (!sheet) sheet = workbook.worksheets[0];
    if (!sheet) return res.status(400).json({ message: 'Le fichier Excel ne contient aucune feuille.' });

    // Repère la ligne d'en-têtes parmi les 3 premières lignes (au cas où il y aurait un titre au-dessus)
    let ligneEntete = 1;
    for (let i = 1; i <= Math.min(3, sheet.rowCount); i++) {
      const texteLigne = sheet.getRow(i).values.map((v) => normaliser(v)).join(' ');
      if (texteLigne.includes('code')) { ligneEntete = i; break; }
    }

    const headerMap = {};
    sheet.getRow(ligneEntete).eachCell((cell, colNumber) => {
      headerMap[colNumber] = normaliser(cell.text);
    });

    const utilisees = new Set();
    const marquer = (col) => { if (col) utilisees.add(col); return col; };

    const colCode = marquer(trouverColonne(headerMap, ['code'], utilisees)) || 1;
    const colProcessus = marquer(trouverColonne(headerMap, ['processus'], utilisees));
    const colActivite = marquer(trouverColonne(headerMap, ['activite'], utilisees));
    const colRisques = marquer(trouverColonne(headerMap, ['risques', 'risque'], utilisees));
    const colDescription = marquer(trouverColonne(headerMap, ['controles', 'controle', 'description'], utilisees));
    const colSources = marquer(trouverColonne(headerMap, ['sources', 'source'], utilisees));
    const colSupport = marquer(trouverColonne(headerMap, ['support requis', 'support'], utilisees));
    const colPeriodicite = marquer(trouverColonne(headerMap, ['periodicite'], utilisees));
    const colDates = marquer(trouverColonne(headerMap, ['dates', 'date'], utilisees));
    const colControleurs = marquer(trouverColonne(headerMap, ['controleurs', 'controleur'], utilisees));

    const lire = (row, col) => (col ? row.getCell(Number(col)).text?.trim() : undefined);

    const results = { crees: 0, mis_a_jour: 0, ignores: 0, erreurs: [], feuille_utilisee: feuilleUtilisee };

    for (let i = ligneEntete + 1; i <= sheet.rowCount; i++) {
      const row = sheet.getRow(i);
      const code = lire(row, colCode);

      if (!code || !CODE_VALIDE.test(code)) {
        if (code) results.ignores++;
        continue;
      }

      const periodiciteRaw = lire(row, colPeriodicite);
      const periodicite = ALIAS_PERIODICITE[normaliser(periodiciteRaw)] || 'Mensuelle';
      if (!ALIAS_PERIODICITE[normaliser(periodiciteRaw)] && results.crees + results.mis_a_jour < 15) {
        console.log(`[DEBUG import] Ligne ${i} code=${code} : periodiciteRaw brut = ${JSON.stringify(periodiciteRaw)} (colonne détectée: ${colPeriodicite}, en-tête: "${headerMap[colPeriodicite]}")`);
      }

      const data = {
        code,
        processus: lire(row, colProcessus),
        activite: lire(row, colActivite),
        risques: lire(row, colRisques),
        description: lire(row, colDescription),
        sources: lire(row, colSources),
        support_requis: lire(row, colSupport),
        periodicite,
        dates: lire(row, colDates),
        controleurs: lire(row, colControleurs),
      };

      try {
        const [controle, created] = await Controle.findOrCreate({
          where: { code },
          defaults: data,
        });
        if (!created) {
          await controle.update(data);
          results.mis_a_jour++;
        } else {
          results.crees++;
        }
      } catch (e) {
        results.erreurs.push(`Ligne ${i} (${code}) : ${e.message}`);
      }
    }

    res.json({ message: `Import terminé (feuille "${feuilleUtilisee}").`, ...results });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Erreur lors de la lecture du fichier Excel. Vérifiez le format." });
  }
});

module.exports = router;
