const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Une Décision CODIR est une directive du Comité de Direction confiée à un Contrôleur
// pour exécution (à la différence d'un Plan d'action classique, assigné à un RMO).
const DecisionCodir = sequelize.define('DecisionCodir', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true }, // ex: DC-2026-A1B2C3
  intitule: { type: DataTypes.TEXT, allowNull: false },
  date_decision: { type: DataTypes.DATEONLY },
  date_echeance: { type: DataTypes.DATEONLY, allowNull: false },
  responsable_id: { type: DataTypes.INTEGER, allowNull: false }, // le Contrôleur en charge de l'exécution
  cree_par_id: { type: DataTypes.INTEGER, allowNull: false },
  statut: {
    type: DataTypes.ENUM('en_cours', 'applique', 'refuse', 'echu', 'abandonne'),
    allowNull: false,
    defaultValue: 'en_cours',
  },
  commentaire: { type: DataTypes.TEXT, allowNull: true },
  notifie_retard: { type: DataTypes.BOOLEAN, defaultValue: false },
}, {
  tableName: 'decisions_codir',
});

module.exports = DecisionCodir;
