const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Une Décision CODIR est une directive du Comité de Direction, historiquement envoyée par
// email aux départements concernés. Elle est désormais importée depuis le fichier Excel type
// utilisé par le CODIR, puis assignée manuellement à un RMO avant envoi (email + visibilité).
const DecisionCodir = sequelize.define('DecisionCodir', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true }, // ex: DC-2026-A1B2C3
  numero: { type: DataTypes.STRING, allowNull: true },              // colonne "N°" du fichier CODIR
  intitule: { type: DataTypes.TEXT, allowNull: false },             // colonne "ACTIONS"
  rmo_suggere: { type: DataTypes.STRING, allowNull: true },         // colonne "RMO" brute du fichier (informatif, avant assignation réelle)
  date_decision: { type: DataTypes.DATEONLY },
  date_echeance: { type: DataTypes.DATEONLY, allowNull: true },     // devient obligatoire au moment de l'envoi
  responsable_id: { type: DataTypes.INTEGER, allowNull: true },     // le RMO (ou Contrôleur) réellement assigné, choisi manuellement
  cree_par_id: { type: DataTypes.INTEGER, allowNull: false },
  statut: {
    type: DataTypes.ENUM('en_cours', 'applique', 'refuse', 'echu', 'abandonne'),
    allowNull: false,
    defaultValue: 'en_cours',
  },
  statut_envoi: {
    type: DataTypes.ENUM('brouillon', 'envoyee'),
    allowNull: false,
    defaultValue: 'brouillon',
  },
  commentaire: { type: DataTypes.TEXT, allowNull: true },           // colonne "OBSERVATIONS", modifiable par le RMO ensuite
  fichier_nom: { type: DataTypes.STRING, allowNull: true },         // pièce jointe facultative ajoutée par le RMO
  fichier_chemin: { type: DataTypes.STRING, allowNull: true },
  notifie_retard: { type: DataTypes.BOOLEAN, defaultValue: false },
}, {
  tableName: 'decisions_codir',
});

module.exports = DecisionCodir;
