const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Controle = sequelize.define('Controle', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true },
  processus: { type: DataTypes.STRING },
  activite: { type: DataTypes.STRING },
  risques: { type: DataTypes.TEXT },              // colonne "RISQUES"
  description: { type: DataTypes.TEXT },           // colonne "CONTROLES" (libellé du contrôle)
  sources: { type: DataTypes.STRING },             // colonne "SOURCES" (ex: BGFIBank Madagascar)
  support_requis: { type: DataTypes.TEXT },        // colonne "SUPPORT REQUIS"
  periodicite: {
    type: DataTypes.ENUM('Hebdomadaire', 'Mensuelle', 'Trimestrielle', 'Semestrielle', 'Annuelle'),
    allowNull: false,
    defaultValue: 'Mensuelle',
  },
  dates: { type: DataTypes.STRING },               // colonne "Dates" (ex: "Mars/septembre du 15 au 20")
  responsable_id: { type: DataTypes.INTEGER, allowNull: true }, // RMO en charge du controle
  taux_conformite: { type: DataTypes.FLOAT, defaultValue: null }, // dernier taux constaté (via FDT)
  prochaine_evaluation: { type: DataTypes.DATEONLY },
  actif: { type: DataTypes.BOOLEAN, defaultValue: true },
}, {
  tableName: 'controles',
});

module.exports = Controle;
