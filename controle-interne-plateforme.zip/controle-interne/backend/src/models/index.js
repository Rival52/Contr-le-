const sequelize = require('../config/database');
const User = require('./User');
const Controle = require('./Controle');
const FeuilleTravail = require('./FeuilleTravail');
const FdtControle = require('./FdtControle');
const PlanAction = require('./PlanAction');
const ActionJustificatif = require('./ActionJustificatif');
const DecisionCodir = require('./DecisionCodir');

// --- Associations ---

// Contrôle <-> Utilisateur (responsable RMO)
Controle.belongsTo(User, { as: 'responsable', foreignKey: 'responsable_id' });
User.hasMany(Controle, { foreignKey: 'responsable_id' });

// FDT <-> Contrôleur/auteur
FeuilleTravail.belongsTo(User, { as: 'auteur', foreignKey: 'uploaded_by' });
User.hasMany(FeuilleTravail, { foreignKey: 'uploaded_by' });

// FDT <-> Contrôles couverts (many-to-many via FdtControle, avec la période comme info supplémentaire)
FeuilleTravail.hasMany(FdtControle, { as: 'liens', foreignKey: 'fdt_id', onDelete: 'CASCADE' });
FdtControle.belongsTo(FeuilleTravail, { as: 'fdt', foreignKey: 'fdt_id' });
FdtControle.belongsTo(Controle, { as: 'controle', foreignKey: 'controle_id' });
Controle.hasMany(FdtControle, { as: 'fdtLiens', foreignKey: 'controle_id' });

// Contrôle <-> Plans d'action
Controle.hasMany(PlanAction, { as: 'plansAction', foreignKey: 'controle_id' });
PlanAction.belongsTo(Controle, { as: 'controle', foreignKey: 'controle_id' });

// Plan d'action <-> RMO responsable
PlanAction.belongsTo(User, { as: 'rmo', foreignKey: 'rmo_id' });
User.hasMany(PlanAction, { as: 'plansAssignes', foreignKey: 'rmo_id' });

// Plan d'action <-> Contrôleur créateur
PlanAction.belongsTo(User, { as: 'controleur', foreignKey: 'controleur_id' });

// Plan d'action <-> Justificatifs
PlanAction.hasMany(ActionJustificatif, { as: 'justificatifs', foreignKey: 'plan_action_id', onDelete: 'CASCADE' });
ActionJustificatif.belongsTo(PlanAction, { foreignKey: 'plan_action_id' });
ActionJustificatif.belongsTo(User, { as: 'auteur', foreignKey: 'uploaded_by' });

// Décision CODIR <-> Contrôleur responsable / créateur
DecisionCodir.belongsTo(User, { as: 'responsable', foreignKey: 'responsable_id' });
DecisionCodir.belongsTo(User, { as: 'createur', foreignKey: 'cree_par_id' });
User.hasMany(DecisionCodir, { as: 'decisionsAssignees', foreignKey: 'responsable_id' });

module.exports = {
  sequelize,
  User,
  Controle,
  FeuilleTravail,
  FdtControle,
  PlanAction,
  ActionJustificatif,
  DecisionCodir,
};
