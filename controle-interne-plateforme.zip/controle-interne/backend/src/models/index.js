const sequelize = require('../config/database');
const User = require('./User');
const Controle = require('./Controle');
const FeuilleTravail = require('./FeuilleTravail');
const PlanAction = require('./PlanAction');
const ActionJustificatif = require('./ActionJustificatif');

// --- Associations ---

// Contrôle <-> Utilisateur (responsable RMO)
Controle.belongsTo(User, { as: 'responsable', foreignKey: 'responsable_id' });
User.hasMany(Controle, { foreignKey: 'responsable_id' });

// Contrôle <-> FDT (PDF déposés au fil des périodes)
Controle.hasMany(FeuilleTravail, { as: 'fdts', foreignKey: 'controle_id', onDelete: 'CASCADE' });
FeuilleTravail.belongsTo(Controle, { as: 'controle', foreignKey: 'controle_id' });
FeuilleTravail.belongsTo(User, { as: 'auteur', foreignKey: 'uploaded_by' });

// Contrôle <-> Plans d'action
Controle.hasMany(PlanAction, { as: 'plansAction', foreignKey: 'controle_id' });
PlanAction.belongsTo(Controle, { as: 'controle', foreignKey: 'controle_id' });

// Plan d'action <-> RMO responsable
PlanAction.belongsTo(User, { as: 'rmo', foreignKey: 'rmo_id' });
User.hasMany(PlanAction, { as: 'plansAssignes', foreignKey: 'rmo_id' });

// Plan d'action <-> Contrôleur créateur
PlanAction.belongsTo(User, { as: 'controleur', foreignKey: 'controleur_id' });

// Plan d'action <-> Justificatifs
PlanAction.hasMany(ActionJustificatif, { as: 'justificatifs', foreignKey: 'plan_action_id', onDelete: 'CASCADE' });
ActionJustificatif.belongsTo(PlanAction, { foreignKey: 'plan_action_id' });
ActionJustificatif.belongsTo(User, { as: 'auteur', foreignKey: 'uploaded_by' });

module.exports = {
  sequelize,
  User,
  Controle,
  FeuilleTravail,
  PlanAction,
  ActionJustificatif,
};
