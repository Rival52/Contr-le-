const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const PlanAction = sequelize.define('PlanAction', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true },
  controle_id: { type: DataTypes.INTEGER, allowNull: false },
  recommandation: { type: DataTypes.TEXT, allowNull: false },
  rmo_id: { type: DataTypes.INTEGER, allowNull: false }, // RMO concerné/responsable
  controleur_id: { type: DataTypes.INTEGER, allowNull: false }, // controleur qui a créé le plan
  date_creation: { type: DataTypes.DATEONLY, defaultValue: DataTypes.NOW },
  date_echeance: { type: DataTypes.DATEONLY, allowNull: false },
  statut: {
    type: DataTypes.ENUM(
      'non_echu',            // en cours, delai non depasse
      'en_attente_validation', // RMO a soumis une action, en attente de validation controleur
      'applique',             // valide par le controleur
      'echu',                 // delai depasse sans action validee
      'abandonne'              // abandonne par le controleur
    ),
    allowNull: false,
    defaultValue: 'non_echu',
  },
  commentaire_refus: { type: DataTypes.TEXT, allowNull: true },
  notifie_retard: { type: DataTypes.BOOLEAN, defaultValue: false }, // évite de renvoyer le mail de retard chaque jour
}, {
  tableName: 'plans_action',
});

module.exports = PlanAction;
