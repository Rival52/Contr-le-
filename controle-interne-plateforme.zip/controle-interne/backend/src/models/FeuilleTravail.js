const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// La FDT est le PDF signé (scanné) prouvant qu'un contrôle a été réalisé sur une période donnée.
// C'est le code de contrôle contenu dans le formulaire qui permet à la plateforme de savoir
// que le contrôle a été effectué pour la période en cours (taux de conformité = 100%),
// sinon le contrôle reste à 0% tant qu'aucune FDT n'est déposée pour la période attendue.
const FeuilleTravail = sequelize.define('FeuilleTravail', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true }, // ex: FDT-2026-A1B2C3
  controle_id: { type: DataTypes.INTEGER, allowNull: false },
  periode_label: { type: DataTypes.STRING, allowNull: false }, // ex: "2026-08", "2026-T3", "2026-S2", "2026"
  nom_fichier: { type: DataTypes.STRING, allowNull: false },
  chemin_fichier: { type: DataTypes.STRING, allowNull: false },
  uploaded_by: { type: DataTypes.INTEGER, allowNull: false },
}, {
  tableName: 'feuilles_travail',
  indexes: [{ unique: true, fields: ['controle_id', 'periode_label'] }],
});

module.exports = FeuilleTravail;
