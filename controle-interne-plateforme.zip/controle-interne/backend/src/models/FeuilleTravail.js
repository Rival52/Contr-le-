const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// La FDT est le PDF signé (scanné) prouvant qu'un ou plusieurs contrôles ont été réalisés.
// Les contrôles couverts par ce document sont listés dans la table de liaison FdtControle.
const FeuilleTravail = sequelize.define('FeuilleTravail', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  code: { type: DataTypes.STRING, allowNull: false, unique: true }, // ex: FDT-2026-A1B2C3
  nom_fichier: { type: DataTypes.STRING, allowNull: false },
  chemin_fichier: { type: DataTypes.STRING, allowNull: false },
  uploaded_by: { type: DataTypes.INTEGER, allowNull: false },
}, {
  tableName: 'feuilles_travail',
});

module.exports = FeuilleTravail;
