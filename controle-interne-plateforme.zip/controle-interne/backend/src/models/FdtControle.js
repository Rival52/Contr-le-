const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

// Une FDT (un seul PDF) peut couvrir plusieurs codes de contrôle à la fois.
// Chaque ligne ici représente : "ce contrôle est couvert par cette FDT, pour cette période".
const FdtControle = sequelize.define('FdtControle', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  fdt_id: { type: DataTypes.INTEGER, allowNull: false },
  controle_id: { type: DataTypes.INTEGER, allowNull: false },
  periode_label: { type: DataTypes.STRING, allowNull: false }, // ex: "2026-08", "2026-T3"
}, {
  tableName: 'fdt_controles',
  indexes: [{ unique: true, fields: ['controle_id', 'periode_label'] }],
});

module.exports = FdtControle;
