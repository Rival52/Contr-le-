const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const ActionJustificatif = sequelize.define('ActionJustificatif', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  plan_action_id: { type: DataTypes.INTEGER, allowNull: false },
  nom_fichier: { type: DataTypes.STRING, allowNull: false },
  chemin_fichier: { type: DataTypes.STRING, allowNull: false },
  commentaire: { type: DataTypes.TEXT },
  uploaded_by: { type: DataTypes.INTEGER, allowNull: false },
}, {
  tableName: 'action_justificatifs',
});

module.exports = ActionJustificatif;
