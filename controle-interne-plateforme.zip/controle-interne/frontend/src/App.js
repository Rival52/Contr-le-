import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './api/AuthContext';
import Login from './pages/Login';
import MotDePasseOublie from './pages/MotDePasseOublie';
import ReinitialiserMotDePasse from './pages/ReinitialiserMotDePasse';
import Accueil from './pages/Accueil';
import ControlesListe from './pages/ControlesListe';
import ControleDetail from './pages/ControleDetail';
import FdtListe from './pages/FdtListe';
import PlansActionListe from './pages/PlansActionListe';
import PlanActionDetail from './pages/PlanActionDetail';
import DecisionsCodirListe from './pages/DecisionsCodirListe';
import Utilisateurs from './pages/Utilisateurs';
import Layout from './components/Layout';

function RoutePrivee({ children, rolesAutorises }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (rolesAutorises && !rolesAutorises.includes(user.role)) {
    return <Navigate to="/" replace />;
  }
  return children;
}

function AppRoutes() {
  const { user } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={user ? <Navigate to="/" replace /> : <Login />} />
      <Route path="/mot-de-passe-oublie" element={user ? <Navigate to="/" replace /> : <MotDePasseOublie />} />
      <Route path="/reinitialiser-mot-de-passe/:token" element={user ? <Navigate to="/" replace /> : <ReinitialiserMotDePasse />} />

      <Route path="/" element={<RoutePrivee><Layout><Accueil /></Layout></RoutePrivee>} />

      <Route path="/controles" element={<RoutePrivee rolesAutorises={['admin', 'controleur']}><Layout module="controle"><ControlesListe /></Layout></RoutePrivee>} />
      <Route path="/controles/:id" element={<RoutePrivee rolesAutorises={['admin', 'controleur']}><Layout module="controle"><ControleDetail /></Layout></RoutePrivee>} />

      <Route path="/fdt" element={<RoutePrivee rolesAutorises={['admin', 'controleur']}><Layout module="controle"><FdtListe /></Layout></RoutePrivee>} />

      <Route path="/plans-action" element={<RoutePrivee rolesAutorises={['admin', 'controleur', 'rmo']}><Layout module="plan-action"><PlansActionListe /></Layout></RoutePrivee>} />
      <Route path="/plans-action/:id" element={<RoutePrivee rolesAutorises={['admin', 'controleur', 'rmo']}><Layout module="plan-action"><PlanActionDetail /></Layout></RoutePrivee>} />

      <Route path="/decisions-codir" element={<RoutePrivee rolesAutorises={['admin', 'controleur', 'codir', 'rmo']}><Layout module="plan-action"><DecisionsCodirListe /></Layout></RoutePrivee>} />

      <Route
        path="/utilisateurs"
        element={
          <RoutePrivee rolesAutorises={['admin']}>
            <Layout><Utilisateurs /></Layout>
          </RoutePrivee>
        }
      />

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
