import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import client from '../api/client';
import logo from '../assets/logo.png';
import bg from '../assets/login-bg.png';

export default function MotDePasseOublie() {
  const [email, setEmail] = useState('');
  const [envoye, setEnvoye] = useState(false);
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setChargement(true);
    try {
      await client.post('/auth/mot-de-passe-oublie', { email });
      setEnvoye(true);
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur, réessayez plus tard.');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="login-page" style={{ backgroundImage: `url(${bg})` }}>
      <form className="login-card" onSubmit={submit}>
        <img src={logo} alt="Logo" className="logo" />
        <span className="brand-name">OPTIKA</span>
        <h2>Mot de passe oublié</h2>

        {envoye ? (
          <div className="inline-alert inline-alert-success" style={{ textAlign: 'left' }}>
            Si un compte existe avec cet email, un lien de réinitialisation vient de vous être envoyé.
            Pensez à vérifier vos courriers indésirables.
          </div>
        ) : (
          <>
            {erreur && <div className="erreur">{erreur}</div>}
            <p style={{ fontSize: 13, color: 'var(--texte-mute)', textAlign: 'left', marginTop: 0 }}>
              Indiquez l'adresse email associée à votre compte, nous vous enverrons un lien pour
              choisir un nouveau mot de passe.
            </p>
            <input
              type="email"
              placeholder="Adresse email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="submit" disabled={chargement}>
              {chargement ? 'Envoi...' : 'Envoyer le lien'}
            </button>
          </>
        )}

        <Link to="/login" style={{ display: 'block', marginTop: 18, fontSize: 13, color: 'var(--accent)', fontWeight: 600, textDecoration: 'none' }}>
          Retour à la connexion
        </Link>
      </form>
    </div>
  );
}
