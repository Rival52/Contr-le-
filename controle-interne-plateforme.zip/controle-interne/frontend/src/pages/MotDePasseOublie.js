import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import client from '../api/client';
import logo from '../assets/logo.png';

export default function MotDePasseOublie() {
  const [email, setEmail] = useState('');
  const [envoye, setEnvoye] = useState(false);
  const [chargement, setChargement] = useState(false);
  const [erreur, setErreur] = useState('');

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setChargement(true);
    try {
      await client.post('/auth/mot-de-passe-oublie', { email });
      setEnvoye(true);
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur, réessayez plus tard.');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="login-page-v2">
      <form className="login-card-v2-solo" onSubmit={submit}>
        <div className="login-brand-row">
          <img src={logo} alt="Logo" className="login-logo-sm" />
          <span className="brand-name" style={{ fontSize: 19 }}>OPTIKA</span>
        </div>
        <h1>Mot de passe oublié</h1>

        {envoye ? (
          <div className="inline-alert inline-alert-success" style={{ textAlign: 'left', marginTop: 16 }}>
            Si un compte existe avec cet email, un lien de réinitialisation vient de vous être envoyé.
            Pensez à vérifier vos courriers indésirables.
          </div>
        ) : (
          <>
            <p className="login-sous-titre">
              Indiquez l'adresse email associée à votre compte, nous vous enverrons un lien pour
              choisir un nouveau mot de passe.
            </p>
            {erreur && <div className="erreur">{erreur}</div>}
            <label className="login-label">Adresse email</label>
            <input
              type="email"
              placeholder="nom@bgfi.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <button type="submit" disabled={chargement}>
              {chargement ? 'Envoi...' : 'Envoyer le lien'}
            </button>
          </>
        )}

        <Link to="/login" className="login-lien-secondaire">Retour à la connexion</Link>
      </form>
    </div>
  );
}
