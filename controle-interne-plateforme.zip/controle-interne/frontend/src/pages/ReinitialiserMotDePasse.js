import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import client from '../api/client';
import logo from '../assets/logo.png';
import bg from '../assets/login-bg.png';

export default function ReinitialiserMotDePasse() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [erreur, setErreur] = useState('');
  const [chargement, setChargement] = useState(false);
  const [succes, setSucces] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    if (password !== confirmation) {
      setErreur('Les deux mots de passe ne correspondent pas.');
      return;
    }
    setChargement(true);
    try {
      await client.post('/auth/reinitialiser-mot-de-passe', { token, password });
      setSucces(true);
      setTimeout(() => navigate('/login'), 2500);
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la réinitialisation.');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="login-page" style={{ backgroundImage: `url(${bg})` }}>
      <form className="login-card" onSubmit={submit}>
        <img src={logo} alt="Logo" className="logo" />
        <span className="brand-name">OPTIKA</span>
        <h2>Nouveau mot de passe</h2>

        {succes ? (
          <div className="inline-alert inline-alert-success">
            Mot de passe réinitialisé. Redirection vers la connexion...
          </div>
        ) : (
          <>
            {erreur && <div className="erreur">{erreur}</div>}
            <input
              type="password"
              placeholder="Nouveau mot de passe"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
            <input
              type="password"
              placeholder="Confirmer le mot de passe"
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              required
              minLength={6}
            />
            <button type="submit" disabled={chargement}>
              {chargement ? 'Enregistrement...' : 'Réinitialiser le mot de passe'}
            </button>
          </>
        )}

        <Link to="/login" style={{ display: 'block', marginTop: 18, fontSize: 13, color: 'var(--accent)', fontWeight: 600, textDecoration: 'none' }}>
          Retour à la connexion
        </Link>
      </form>
    </div>
  );
}
