import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import client from '../api/client';
import logo from '../assets/logo.png';

export default function ReinitialiserMotDePasse() {
  const { token } = useParams();
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmation, setConfirmation] = useState('');
  const [erreur, setErreur] = useState('');
  const [chargement, setChargement] = useState(false);
  const [succes, setSucces] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    if (password !== confirmation) {
      setErreur('Les deux mots de passe ne correspondent pas.');
      return;
    }
    setChargement(true);
    try {
      await client.post('/auth/reinitialiser-mot-de-passe', { token, password });
      setSucces(true);
      setTimeout(() => navigate('/login'), 2500);
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la réinitialisation.');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="login-page-v2">
      <form className="login-card-v2-solo" onSubmit={submit}>
        <div className="login-brand-row">
          <img src={logo} alt="Logo" className="login-logo-sm" />
          <span className="brand-name" style={{ fontSize: 19 }}>OPTIKA</span>
        </div>
        <h1>Nouveau mot de passe</h1>

        {succes ? (
          <div className="inline-alert inline-alert-success" style={{ marginTop: 16 }}>
            Mot de passe réinitialisé. Redirection vers la connexion...
          </div>
        ) : (
          <>
            <p className="login-sous-titre">Choisissez un nouveau mot de passe pour votre compte.</p>
            {erreur && <div className="erreur">{erreur}</div>}
            <label className="login-label">Nouveau mot de passe</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              minLength={6}
            />
            <label className="login-label">Confirmer le mot de passe</label>
            <input
              type="password"
              placeholder="••••••••"
              value={confirmation}
              onChange={(e) => setConfirmation(e.target.value)}
              required
              minLength={6}
            />
            <button type="submit" disabled={chargement}>
              {chargement ? 'Enregistrement...' : 'Réinitialiser le mot de passe'}
            </button>
          </>
        )}

        <Link to="/login" className="login-lien-secondaire">Retour à la connexion</Link>
      </form>
    </div>
  );
}
