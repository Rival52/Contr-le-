import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import client from '../api/client';
import { IconDownload } from '../components/Icons';

export default function ControleDetail() {
  const { id } = useParams();
  const [controle, setControle] = useState(null);
  const [fdts, setFdts] = useState([]);

  useEffect(() => {
    client.get(`/controles/${id}`).then(({ data }) => setControle(data));
  }, [id]);

  useEffect(() => {
    if (!controle) return;
    client.get('/fdt', { params: { controle_code: controle.code } }).then(({ data }) => setFdts(data));
  }, [controle]);

  const telecharger = (fdtId) => {
    window.open(`${client.defaults.baseURL}/fdt/${fdtId}/download`, '_blank');
  };

  if (!controle) return <div className="page-content">Chargement...</div>;

  const conforme = controle.taux_conformite === 100;

  return (
    <>
      <div className="page-banner controle">
        <div className="fil"><Link to="/controles" style={{ color: 'white' }}>Contrôles</Link> / {controle.code}</div>
        <h1>{controle.code} — {controle.processus}</h1>
      </div>
      <div className="page-content">
        <div className="card-panel">
          <div className="form-grid">
            <div><label>Activité</label><div>{controle.activite || '-'}</div></div>
            <div><label>Sources</label><div>{controle.sources || '-'}</div></div>
            <div><label>Périodicité</label><div>{controle.periodicite}</div></div>
            <div><label>Période en cours</label><div>{controle.periode_courante}</div></div>
            <div><label>Responsable</label><div>{controle.responsable ? `${controle.responsable.prenom} ${controle.responsable.nom}` : '-'}</div></div>
            <div>
              <label>Conformité période en cours</label>
              <span className="badge" style={{ background: conforme ? 'var(--succes)' : 'var(--danger)' }}>
                {controle.taux_conformite}% {conforme ? '— FDT déposée' : '— FDT manquante'}
              </span>
            </div>
          </div>
          {controle.risques && (
            <div style={{ marginTop: 10 }}>
              <label style={{ fontSize: 12, color: '#667' }}>Risques</label>
              <div>{controle.risques}</div>
            </div>
          )}
          {controle.description && (
            <div style={{ marginTop: 10 }}>
              <label style={{ fontSize: 12, color: '#667' }}>Description du contrôle</label>
              <div>{controle.description}</div>
            </div>
          )}
          {controle.support_requis && (
            <div style={{ marginTop: 10 }}>
              <label style={{ fontSize: 12, color: '#667' }}>Support requis</label>
              <div>{controle.support_requis}</div>
            </div>
          )}
        </div>

        <div className="section-header">
          <h3>Historique des FDT déposées</h3>
          <Link to="/fdt" className="btn btn-outline btn-sm">Déposer une nouvelle FDT</Link>
        </div>

        {fdts.length === 0 ? (
          <div className="empty-state">Aucune FDT n'a encore été déposée pour ce contrôle.</div>
        ) : (
          <table className="data-table">
            <thead><tr><th>Code FDT</th><th>Période</th><th>Déposée par</th><th></th></tr></thead>
            <tbody>
              {fdts.map((f) => (
                <tr key={f.id}>
                  <td style={{ fontWeight: 700, color: 'var(--controle)' }}>{f.code}</td>
                  <td>{f.periode_libelle}</td>
                  <td>{f.auteur ? `${f.auteur.prenom} ${f.auteur.nom}` : '-'}</td>
                  <td>
                    <button className="btn btn-outline btn-sm" onClick={() => telecharger(f.id)}>
                      <IconDownload width={13} height={13} /> Télécharger
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
