import React, { useEffect, useRef, useState } from 'react';
import client, { telechargerFichier } from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconPlus, IconDownload, IconSearch, IconX, IconUpload, IconFile, Spinner } from '../components/Icons';

const LIBELLES_STATUT = {
  en_cours: 'En cours',
  applique: 'Appliqué',
  refuse: 'Refusé',
  echu: 'Échu',
  abandonne: 'Abandonné',
};

export default function DecisionsCodirListe() {
  const { user } = useAuth();
  const estGerant = ['admin', 'codir'].includes(user?.role);

  return estGerant ? <VueGerant /> : <VueRmo />;
}

// ============ VUE RMO (simplifiée : ses décisions envoyées uniquement) ============
function VueRmo() {
  const [decisions, setDecisions] = useState([]);
  const [decisionACommenter, setDecisionACommenter] = useState(null);
  const [chargement, setChargement] = useState(false);

  const charger = async () => {
    setChargement(true);
    try {
      const { data } = await client.get('/decisions-codir');
      setDecisions(data);
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => { charger(); }, []);

  return (
    <>
      <div className="page-banner plan-action">
        <div className="fil">OPTIKA / Décisions CODIR</div>
        <h1>Mes décisions CODIR</h1>
      </div>
      <div className="page-content">
        <p style={{ color: 'var(--texte-mute)', fontSize: 13.5, marginTop: 0 }}>
          Actions qui vous ont été confiées par le Comité de Direction, en tant que RMO ou contrôleur assigné. Mettez à jour le statut
          et ajoutez vos observations au fil de l'avancement.
        </p>

        {chargement ? (
          <p>Chargement...</p>
        ) : decisions.length === 0 ? (
          <div className="empty-state">Aucune décision CODIR ne vous a été assignée pour le moment.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Code</th><th>Action</th><th>Échéance</th><th>Statut</th><th>Observations</th><th></th></tr>
            </thead>
            <tbody>
              {decisions.map((d) => (
                <tr key={d.id}>
                  <td style={{ fontWeight: 700 }}>{d.numero ? `N°${d.numero} · ` : ''}{d.code}</td>
                  <td>{d.intitule}</td>
                  <td>{d.date_echeance}</td>
                  <td>
                    {!['applique', 'abandonne'].includes(d.statut) ? (
                      <select
                        value={d.statut}
                        onChange={async (e) => { await client.put(`/decisions-codir/${d.id}`, { statut: e.target.value }); charger(); }}
                        style={{ padding: '6px 8px', borderRadius: 6, border: '1px solid var(--bordure)', fontSize: 12.5 }}
                      >
                        {Object.entries(LIBELLES_STATUT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                      </select>
                    ) : (
                      <span className={`badge ${d.statut_affiche}`}>{LIBELLES_STATUT[d.statut_affiche]}</span>
                    )}
                  </td>
                  <td>
                    {d.commentaire?.slice(0, 40) || '-'}{d.commentaire?.length > 40 ? '...' : ''}
                    {d.fichier_nom && <IconFile width={12} height={12} style={{ display: 'inline', marginLeft: 5, color: 'var(--texte-mute)', verticalAlign: 'middle' }} />}
                  </td>
                  <td><button className="btn btn-outline btn-sm" onClick={() => setDecisionACommenter(d)}>Commenter</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {decisionACommenter && (
        <ModalCommentaireRmo decision={decisionACommenter} onClose={() => setDecisionACommenter(null)} onSaved={() => { setDecisionACommenter(null); charger(); }} />
      )}
    </>
  );
}

function ModalCommentaireRmo({ decision, onClose, onSaved }) {
  const [commentaire, setCommentaire] = useState(decision.commentaire || '');
  const [statut, setStatut] = useState(decision.statut);
  const [envoi, setEnvoi] = useState(false);
  const [erreur, setErreur] = useState('');
  const fileInputRef = useRef(null);
  const [fichier, setFichier] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      const formData = new FormData();
      formData.append('commentaire', commentaire);
      if (statut !== decision.statut) formData.append('statut', statut);
      if (fichier) formData.append('fichier', fichier);
      await client.post(`/decisions-codir/${decision.id}/reponse`, formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      onSaved();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de l\'enregistrement.');
    } finally {
      setEnvoi(false);
    }
  };

  const telechargerFichierExistant = () => {
    telechargerFichier(`/decisions-codir/${decision.id}/fichier/download`, decision.fichier_nom);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>{decision.code}</h3>
        <p style={{ fontSize: 13, color: 'var(--texte-mute)', marginTop: 0 }}>{decision.intitule}</p>
        {erreur && <div className="inline-alert inline-alert-error">{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid full">
            <div>
              <label>Statut</label>
              <select value={statut} onChange={(e) => setStatut(e.target.value)} disabled={['applique', 'abandonne'].includes(decision.statut)}>
                {Object.entries(LIBELLES_STATUT).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Vos observations</label>
              <textarea rows={9} style={{ minHeight: 160, resize: 'vertical' }} value={commentaire} onChange={(e) => setCommentaire(e.target.value)} placeholder="Avancement, précisions, blocages éventuels..." />
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Pièce jointe (facultative)</label>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={(e) => setFichier(e.target.files[0])} />
                <button type="button" className="btn btn-outline btn-sm" onClick={() => fileInputRef.current?.click()}>
                  {fichier ? fichier.name : 'Choisir un fichier'}
                </button>
                {decision.fichier_nom && !fichier && (
                  <button type="button" className="btn btn-outline btn-sm" onClick={telechargerFichierExistant}>
                    Voir le fichier déjà envoyé ({decision.fichier_nom})
                  </button>
                )}
              </div>
              <p style={{ fontSize: 11.5, color: 'var(--texte-mute)', margin: '6px 0 0' }}>
                Un commentaire seul suffit pour soumettre — le fichier n'est pas obligatoire.
              </p>
            </div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Enregistrement...' : 'Enregistrer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

// ============ VUE GÉRANT (admin/contrôleur/codir) : import, assignation, envoi ============
function VueGerant() {
  const [decisions, setDecisions] = useState([]);
  const [utilisateurs, setUtilisateurs] = useState([]);
  const [recherche, setRecherche] = useState('');
  const [ongletActif, setOngletActif] = useState('brouillons');
  const [modalOuvert, setModalOuvert] = useState(false);
  const [decisionAModifier, setDecisionAModifier] = useState(null);
  const [chargement, setChargement] = useState(false);
  const [message, setMessage] = useState(null);
  const [envoiEnCours, setEnvoiEnCours] = useState(null);
  const fileInputRef = useRef(null);

  const charger = async () => {
    setChargement(true);
    try {
      const [{ data: dec }, { data: users }] = await Promise.all([
        client.get('/decisions-codir'),
        client.get('/users'),
      ]);
      setDecisions(dec);
      setUtilisateurs(users.filter((u) => ['rmo', 'controleur', 'admin'].includes(u.role)));
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => { charger(); }, []);

  const brouillons = decisions.filter((d) => d.statut_envoi === 'brouillon');
  const envoyees = decisions.filter((d) => d.statut_envoi === 'envoyee');
  const listeAffichee = (ongletActif === 'brouillons' ? brouillons : envoyees).filter((d) => {
    if (!recherche.trim()) return true;
    const q = recherche.toLowerCase();
    return d.code?.toLowerCase().includes(q) || d.intitule?.toLowerCase().includes(q) || `${d.responsable?.prenom} ${d.responsable?.nom}`.toLowerCase().includes(q);
  });

  const handleImportClick = () => fileInputRef.current?.click();

  const handleImportFile = async (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;
    setMessage(null);
    const formData = new FormData();
    formData.append('fichier', fichier);
    try {
      const { data } = await client.post('/decisions-codir/import', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMessage({ type: 'succes', texte: data.message });
      setOngletActif('brouillons');
      charger();
    } catch (err) {
      setMessage({ type: 'erreur', texte: err.response?.data?.message || 'Erreur lors de l\'import.' });
    } finally {
      e.target.value = '';
    }
  };

  const assigner = async (id, responsable_id) => {
    if (!responsable_id) return;
    await client.put(`/decisions-codir/${id}/assigner`, { responsable_id });
    charger();
  };

  const modifierEcheanceBrouillon = async (id, date_echeance) => {
    await client.put(`/decisions-codir/${id}`, { date_echeance });
    charger();
  };

  const envoyer = async (id) => {
    setEnvoiEnCours(id);
    try {
      await client.post(`/decisions-codir/${id}/envoyer`);
      charger();
    } catch (err) {
      alert(err.response?.data?.message || 'Erreur lors de l\'envoi.');
    } finally {
      setEnvoiEnCours(null);
    }
  };

  const envoyerTout = async () => {
    if (!window.confirm('Envoyer toutes les décisions en brouillon déjà assignées avec une échéance ? Un email sera envoyé à chaque responsable.')) return;
    const { data } = await client.post('/decisions-codir/envoyer-tout');
    setMessage({ type: 'succes', texte: data.message });
    charger();
  };

  const supprimer = async (id) => {
    if (!window.confirm('Confirmer la suppression de cette décision CODIR ?')) return;
    try {
      await client.delete(`/decisions-codir/${id}`);
      charger();
    } catch (err) {
      setMessage({ type: 'erreur', texte: err.response?.data?.message || 'Erreur lors de la suppression.' });
    }
  };

  const handleExport = () => telechargerFichier('/decisions-codir/export/excel', 'decisions_codir.xlsx');

  const prêtesAEnvoyer = brouillons.filter((d) => d.responsable_id && d.date_echeance);

  return (
    <>
      <div className="page-banner plan-action">
        <div className="fil">OPTIKA / Suivi des Décisions CODIR</div>
        <h1>Suivi des Décisions CODIR</h1>
      </div>
      <div className="page-content">
        <div className="card-panel">
          <h3 className="card-title">Importer le fichier CODIR</h3>
          <input type="file" ref={fileInputRef} accept=".xlsx,.xls" style={{ display: 'none' }} onChange={handleImportFile} />
          <button className="btn btn-success" onClick={handleImportClick}><IconUpload width={14} height={14} /> Importer un fichier Excel</button>
          {message && (
            <div className={`inline-alert ${message.type === 'succes' ? 'inline-alert-success' : 'inline-alert-error'}`}>{message.texte}</div>
          )}
        </div>

        <div className="actions-bar">
          <div className="search-box">
            <IconSearch width={15} height={15} />
            <input placeholder="Rechercher..." value={recherche} onChange={(e) => setRecherche(e.target.value)} />
          </div>
          <button className="btn btn-outline" onClick={handleExport}><IconDownload width={14} height={14} /> Excel - décisions CODIR</button>
          <button className="btn btn-success" onClick={() => setModalOuvert(true)}><IconPlus width={14} height={14} /> Ajouter manuellement</button>
        </div>

        <div style={{ display: 'flex', gap: 6, marginBottom: 16 }}>
          <button
            className={ongletActif === 'brouillons' ? 'btn btn-primary btn-sm' : 'btn btn-outline btn-sm'}
            onClick={() => setOngletActif('brouillons')}
          >
            Brouillons ({brouillons.length})
          </button>
          <button
            className={ongletActif === 'envoyees' ? 'btn btn-primary btn-sm' : 'btn btn-outline btn-sm'}
            onClick={() => setOngletActif('envoyees')}
          >
            Envoyées ({envoyees.length})
          </button>
          {ongletActif === 'brouillons' && prêtesAEnvoyer.length > 0 && (
            <button className="btn btn-success btn-sm" style={{ marginLeft: 'auto' }} onClick={envoyerTout}>
              Envoyer les {prêtesAEnvoyer.length} décision(s) prête(s)
            </button>
          )}
        </div>

        {chargement ? (
          <p>Chargement...</p>
        ) : listeAffichee.length === 0 ? (
          <div className="empty-state">{ongletActif === 'brouillons' ? 'Aucun brouillon en attente.' : 'Aucune décision envoyée.'}</div>
        ) : ongletActif === 'brouillons' ? (
          <table className="data-table">
            <thead>
              <tr><th>N°</th><th>Action</th><th>RMO (fichier)</th><th>Assigner à</th><th>Échéance</th><th></th></tr>
            </thead>
            <tbody>
              {listeAffichee.map((d) => (
                <tr key={d.id}>
                  <td>{d.numero || '-'}</td>
                  <td>{d.intitule?.slice(0, 70)}{d.intitule?.length > 70 ? '...' : ''}</td>
                  <td style={{ color: 'var(--texte-mute)' }}>{d.rmo_suggere || '-'}</td>
                  <td>
                    <select
                      value={d.responsable_id || ''}
                      onChange={(e) => assigner(d.id, e.target.value)}
                      style={{ padding: '6px 8px', borderRadius: 6, border: '1px solid var(--bordure)', fontSize: 12.5 }}
                    >
                      <option value="">-- Choisir --</option>
                      {utilisateurs.map((u) => (
                        <option key={u.id} value={u.id}>{u.prenom} {u.nom} ({u.role.toUpperCase()})</option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <input
                      type="date"
                      defaultValue={d.date_echeance || ''}
                      onBlur={(e) => e.target.value && modifierEcheanceBrouillon(d.id, e.target.value)}
                      style={{ padding: '6px 8px', borderRadius: 6, border: '1px solid var(--bordure)', fontSize: 12.5 }}
                    />
                  </td>
                  <td style={{ display: 'flex', gap: 6 }}>
                    <button
                      className="btn btn-success btn-sm"
                      onClick={() => envoyer(d.id)}
                      disabled={!d.responsable_id || !d.date_echeance || envoiEnCours === d.id}
                    >
                      {envoiEnCours === d.id ? <Spinner /> : 'Envoyer'}
                    </button>
                    <button className="btn btn-danger btn-sm" onClick={() => supprimer(d.id)}><IconX width={12} height={12} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table className="data-table">
            <thead>
              <tr><th>Code</th><th>Action</th><th>Responsable</th><th>Échéance</th><th>Statut</th><th>Observations</th><th></th></tr>
            </thead>
            <tbody>
              {listeAffichee.map((d) => (
                <tr key={d.id}>
                  <td style={{ fontWeight: 700 }}>{d.code}</td>
                  <td>{d.intitule?.slice(0, 60)}{d.intitule?.length > 60 ? '...' : ''}</td>
                  <td>{d.responsable ? `${d.responsable.prenom} ${d.responsable.nom}` : '-'}</td>
                  <td>{d.date_echeance}</td>
                  <td><span className={`badge ${d.statut_affiche}`}>{LIBELLES_STATUT[d.statut_affiche]}</span></td>
                  <td>{d.commentaire?.slice(0, 35) || '-'}{d.commentaire?.length > 35 ? '...' : ''}</td>
                  <td style={{ display: 'flex', gap: 6 }}>
                    <button className="btn btn-outline btn-sm" onClick={() => setDecisionAModifier(d)}>Modifier</button>
                    <button className="btn btn-danger btn-sm" onClick={() => supprimer(d.id)}><IconX width={12} height={12} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalOuvert && (
        <ModalDecisionManuelle onClose={() => setModalOuvert(false)} onSaved={() => { setModalOuvert(false); charger(); }} />
      )}
      {decisionAModifier && (
        <ModalEditionDecision decision={decisionAModifier} onClose={() => setDecisionAModifier(null)} onSaved={() => { setDecisionAModifier(null); charger(); }} />
      )}
    </>
  );
}

function ModalDecisionManuelle({ onClose, onSaved }) {
  const [controleurs, setControleurs] = useState([]);
  const [form, setForm] = useState({ intitule: '', responsable_id: '', date_echeance: '', commentaire: '' });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    client.get('/users').then(({ data }) => setControleurs(data.filter((u) => ['controleur', 'admin', 'rmo'].includes(u.role))));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.post('/decisions-codir', form);
      onSaved();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la création.');
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>Ajouter une décision CODIR</h3>
        <p style={{ fontSize: 12.5, color: 'var(--texte-mute)', marginTop: -6 }}>
          Cette décision sera envoyée immédiatement (email au responsable).
        </p>
        {erreur && <div className="inline-alert inline-alert-error">{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid full">
            <div>
              <label>Intitulé de la décision</label>
              <textarea required rows={4} value={form.intitule} onChange={(e) => setForm({ ...form, intitule: e.target.value })} />
            </div>
          </div>
          <div className="form-grid">
            <div>
              <label>Responsable</label>
              <select required value={form.responsable_id} onChange={(e) => setForm({ ...form, responsable_id: e.target.value })}>
                <option value="">-- Sélectionner --</option>
                {controleurs.map((c) => <option key={c.id} value={c.id}>{c.prenom} {c.nom} ({c.role.toUpperCase()})</option>)}
              </select>
            </div>
            <div>
              <label>Date d'échéance</label>
              <input required type="date" value={form.date_echeance} onChange={(e) => setForm({ ...form, date_echeance: e.target.value })} />
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Observations (optionnel)</label>
              <textarea rows={2} value={form.commentaire} onChange={(e) => setForm({ ...form, commentaire: e.target.value })} />
            </div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Création...' : 'Créer et envoyer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ModalEditionDecision({ decision, onClose, onSaved }) {
  const [utilisateurs, setUtilisateurs] = useState([]);
  const [form, setForm] = useState({
    intitule: decision.intitule,
    responsable_id: decision.responsable_id,
    date_echeance: decision.date_echeance,
    commentaire: decision.commentaire || '',
  });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    client.get('/users').then(({ data }) => setUtilisateurs(data.filter((u) => ['rmo', 'controleur', 'admin'].includes(u.role))));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.put(`/decisions-codir/${decision.id}`, form);
      onSaved();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la modification.');
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>Modifier {decision.code}</h3>
        {erreur && <div className="inline-alert inline-alert-error">{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid full">
            <div>
              <label>Intitulé</label>
              <textarea required rows={4} value={form.intitule} onChange={(e) => setForm({ ...form, intitule: e.target.value })} />
            </div>
          </div>
          <div className="form-grid">
            <div>
              <label>Responsable</label>
              <select required value={form.responsable_id} onChange={(e) => setForm({ ...form, responsable_id: e.target.value })}>
                {utilisateurs.map((u) => <option key={u.id} value={u.id}>{u.prenom} {u.nom} ({u.role.toUpperCase()})</option>)}
              </select>
            </div>
            <div>
              <label>Échéance</label>
              <input required type="date" value={form.date_echeance} onChange={(e) => setForm({ ...form, date_echeance: e.target.value })} />
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Observations</label>
              <textarea rows={3} value={form.commentaire} onChange={(e) => setForm({ ...form, commentaire: e.target.value })} />
            </div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Enregistrement...' : 'Enregistrer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
