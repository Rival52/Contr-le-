import React, { useEffect, useState } from 'react';
import client, { telechargerFichier } from '../api/client';
import { IconPlus, IconDownload, IconSearch } from '../components/Icons';

const LIBELLES_STATUT = {
  en_cours: 'En cours',
  applique: 'Appliqué',
  refuse: 'Refusé',
  echu: 'Échu',
  abandonne: 'Abandonné',
};

export default function DecisionsCodirListe() {
  const [decisions, setDecisions] = useState([]);
  const [recherche, setRecherche] = useState('');
  const [modalOuvert, setModalOuvert] = useState(false);
  const [chargement, setChargement] = useState(false);

  const charger = async () => {
    setChargement(true);
    try {
      const { data } = await client.get('/decisions-codir');
      setDecisions(data);
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => { charger(); }, []);

  const decisionsFiltrees = decisions.filter((d) => {
    if (!recherche.trim()) return true;
    const q = recherche.toLowerCase();
    return (
      d.code?.toLowerCase().includes(q) ||
      d.intitule?.toLowerCase().includes(q) ||
      `${d.responsable?.prenom} ${d.responsable?.nom}`.toLowerCase().includes(q)
    );
  });

  const handleExport = () => telechargerFichier('/decisions-codir/export/excel', 'decisions_codir.xlsx');

  const changerStatut = async (id, statut) => {
    await client.put(`/decisions-codir/${id}`, { statut });
    charger();
  };

  return (
    <>
      <div className="page-banner plan-action">
        <div className="fil">OPTIKA / Suivi des Décisions CODIR</div>
        <h1>Suivi des Décisions CODIR</h1>
      </div>
      <div className="page-content">
        <p style={{ color: 'var(--texte-mute)', fontSize: 13.5, marginTop: 0 }}>
          Directives du Comité de Direction confiées à un contrôleur pour exécution.
        </p>

        <div className="actions-bar">
          <div className="search-box">
            <IconSearch width={15} height={15} />
            <input
              placeholder="Rechercher un code, un intitulé, un responsable..."
              value={recherche}
              onChange={(e) => setRecherche(e.target.value)}
            />
          </div>
          <button className="btn btn-outline" onClick={handleExport}><IconDownload width={14} height={14} /> Excel - décisions CODIR</button>
          <button className="btn btn-success" onClick={() => setModalOuvert(true)}><IconPlus width={14} height={14} /> Ajouter une décision CODIR</button>
        </div>

        {chargement ? (
          <p>Chargement...</p>
        ) : decisionsFiltrees.length === 0 ? (
          <div className="empty-state">Aucune décision CODIR enregistrée.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Intitulé</th>
                <th>Responsable</th>
                <th>Échéance</th>
                <th>Statut</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {decisionsFiltrees.map((d) => (
                <tr key={d.id}>
                  <td style={{ fontWeight: 700 }}>{d.code}</td>
                  <td>{d.intitule?.slice(0, 90)}{d.intitule?.length > 90 ? '...' : ''}</td>
                  <td>{d.responsable ? `${d.responsable.prenom} ${d.responsable.nom}` : '-'}</td>
                  <td>{d.date_echeance}</td>
                  <td><span className={`badge ${d.statut_affiche}`}>{LIBELLES_STATUT[d.statut_affiche]}</span></td>
                  <td>
                    {!['applique', 'abandonne'].includes(d.statut) && (
                      <select
                        value={d.statut}
                        onChange={(e) => changerStatut(d.id, e.target.value)}
                        style={{ padding: '6px 8px', borderRadius: 6, border: '1px solid var(--bordure)', fontSize: 12.5 }}
                      >
                        {Object.entries(LIBELLES_STATUT).map(([k, v]) => (
                          <option key={k} value={k}>{v}</option>
                        ))}
                      </select>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalOuvert && (
        <ModalCreationDecision onClose={() => setModalOuvert(false)} onCreated={() => { setModalOuvert(false); charger(); }} />
      )}
    </>
  );
}

function ModalCreationDecision({ onClose, onCreated }) {
  const [controleurs, setControleurs] = useState([]);
  const [form, setForm] = useState({ intitule: '', responsable_id: '', date_echeance: '', commentaire: '' });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    client.get('/users').then(({ data }) => setControleurs(data.filter((u) => ['controleur', 'admin'].includes(u.role))));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.post('/decisions-codir', form);
      onCreated();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la création.');
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>Ajouter une décision CODIR</h3>
        {erreur && <div className="inline-alert inline-alert-error">{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid full">
            <div>
              <label>Intitulé de la décision</label>
              <textarea required rows={4} value={form.intitule} onChange={(e) => setForm({ ...form, intitule: e.target.value })} />
            </div>
          </div>
          <div className="form-grid">
            <div>
              <label>Contrôleur responsable</label>
              <select required value={form.responsable_id} onChange={(e) => setForm({ ...form, responsable_id: e.target.value })}>
                <option value="">-- Sélectionner --</option>
                {controleurs.map((c) => <option key={c.id} value={c.id}>{c.prenom} {c.nom}</option>)}
              </select>
            </div>
            <div>
              <label>Date d'échéance</label>
              <input required type="date" value={form.date_echeance} onChange={(e) => setForm({ ...form, date_echeance: e.target.value })} />
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Commentaire (optionnel)</label>
              <textarea rows={2} value={form.commentaire} onChange={(e) => setForm({ ...form, commentaire: e.target.value })} />
            </div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Création...' : 'Créer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
