import React, { useEffect, useState } from 'react';
import client from '../api/client';
import { useAuth } from '../api/AuthContext';
import { Link } from 'react-router-dom';
import { IconShieldCheck, IconTrendingUp, IconCheck, IconClock, IconArchive } from '../components/Icons';

export default function Accueil() {
  const { user } = useAuth();
  const estRmo = user?.role === 'rmo';
  const [stats, setStats] = useState(null);
  const [echeancesProches, setEcheancesProches] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const requetes = estRmo
          ? [client.get('/plans-action')]
          : [client.get('/controles'), client.get('/plans-action')];
        const resultats = await Promise.all(requetes);
        const plans = estRmo ? resultats[0].data : resultats[1].data;
        const controles = estRmo ? null : resultats[0].data;

        setStats({
          totalControles: controles?.length,
          conformes: controles?.filter((c) => c.taux_conformite === 100).length,
          totalPlans: plans.length,
          appliques: plans.filter((p) => p.statut_affiche === 'applique').length,
          enAttente: plans.filter((p) => p.statut_affiche === 'en_attente_validation').length,
          echus: plans.filter((p) => p.statut_affiche === 'echu').length,
        });

        const dansUneSemaine = new Date();
        dansUneSemaine.setDate(dansUneSemaine.getDate() + 7);
        const proches = plans
          .filter((p) => !['applique', 'abandonne'].includes(p.statut_affiche))
          .filter((p) => new Date(p.date_echeance) <= dansUneSemaine)
          .sort((a, b) => new Date(a.date_echeance) - new Date(b.date_echeance))
          .slice(0, 5);
        setEcheancesProches(proches);
      } catch (e) {
        console.error(e);
      }
    })();
  }, [estRmo]);

  return (
    <div className="page-content">
      <div style={{ marginBottom: 28 }}>
        <h2 style={{ margin: '0 0 6px', fontSize: 24, fontWeight: 800 }}>
          Bienvenue, {user?.prenom} {user?.nom}
        </h2>
        <p style={{ color: '#6b7280', margin: 0 }}>
          Rôle : <span className={`tag-role ${user?.role}`}>{user?.role?.toUpperCase()}</span>
        </p>
      </div>

      {stats && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(190px, 1fr))', gap: 18, marginBottom: 28 }}>
          {!estRmo && (
            <>
              <CarteStat label="Contrôles suivis" valeur={stats.totalControles} lien="/controles" couleur="#0e7c6b" Icon={IconShieldCheck} />
              <CarteStat label="Conformes (période en cours)" valeur={`${stats.conformes}/${stats.totalControles}`} lien="/controles" couleur="#1f9d55" Icon={IconCheck} />
            </>
          )}
          <CarteStat label="Plans d'action" valeur={stats.totalPlans} lien="/plans-action" couleur="#3d4f8f" Icon={IconTrendingUp} />
          <CarteStat label="En attente de validation" valeur={stats.enAttente} lien="/plans-action" couleur="#dd9615" Icon={IconClock} />
          <CarteStat label="Échus" valeur={stats.echus} lien="/plans-action" couleur="#d0342c" Icon={IconArchive} />
        </div>
      )}

      {echeancesProches.length > 0 && (
        <div className="card-panel">
          <h3 className="card-title">Échéances dans les 7 prochains jours</h3>
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Contrôle</th>
                {!estRmo && <th>RMO</th>}
                <th>Échéance</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {echeancesProches.map((p) => (
                <tr key={p.id}>
                  <td><Link to={`/plans-action/${p.id}`}>{p.code}</Link></td>
                  <td>{p.controle?.code}</td>
                  {!estRmo && <td>{p.rmo ? `${p.rmo.prenom} ${p.rmo.nom}` : '-'}</td>}
                  <td>{p.date_echeance}</td>
                  <td><span className={`badge ${p.statut_affiche}`}>{p.statut_affiche}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function CarteStat({ label, valeur, lien, couleur, Icon }) {
  return (
    <Link to={lien} style={{ textDecoration: 'none' }}>
      <div
        className="card-panel"
        style={{ margin: 0, borderTop: `3px solid ${couleur}`, cursor: 'pointer', transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)' }}
        onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 12px 28px rgba(16,24,40,0.14)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = ''; }}
      >
        <Icon width={20} height={20} style={{ color: couleur, marginBottom: 10 }} />
        <div style={{ fontSize: 26, fontWeight: 800, color: '#1c1f26' }}>{valeur}</div>
        <div style={{ fontSize: 13, color: '#6b7280', marginTop: 4, fontWeight: 600 }}>{label}</div>
      </div>
    </Link>
  );
}
