import React, { useEffect, useState } from 'react';
import client from '../api/client';
import { useAuth } from '../api/AuthContext';
import { Link } from 'react-router-dom';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';
import { IconShieldCheck, IconTrendingUp, IconCheck, IconClock, IconArchive, IconPlus, IconUpload } from '../components/Icons';

const LIBELLES_STATUT_COURT = {
  non_echu: 'En cours',
  en_attente_validation: 'À valider',
  refuse: 'Refusé',
  applique: 'Appliqué',
  echu: 'Échu',
  abandonne: 'Abandonné',
  en_cours: 'En cours',
};

const COULEURS_STATUT = {
  non_echu: '#7d8494',
  en_attente_validation: '#dd9615',
  refuse: '#a4383a',
  applique: '#1f9d55',
  echu: '#d0342c',
  abandonne: '#262626',
  en_cours: '#5568b8',
};

export default function Accueil() {
  const { user } = useAuth();
  const estRmo = user?.role === 'rmo';
  const estCodir = user?.role === 'codir';
  const [stats, setStats] = useState(null);
  const [donneesGraphique, setDonneesGraphique] = useState([]);
  const [echeancesProches, setEcheancesProches] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        if (estCodir) {
          const { data: decisions } = await client.get('/decisions-codir');
          setStats({
            total: decisions.length,
            enCours: decisions.filter((d) => d.statut_affiche === 'en_cours').length,
            appliquees: decisions.filter((d) => d.statut_affiche === 'applique').length,
            echues: decisions.filter((d) => d.statut_affiche === 'echu').length,
          });
          const compteurs = {};
          decisions.forEach((d) => { compteurs[d.statut_affiche] = (compteurs[d.statut_affiche] || 0) + 1; });
          setDonneesGraphique(
            ['en_cours', 'applique', 'refuse', 'echu', 'abandonne'].map((statut) => ({
              statut, nom: LIBELLES_STATUT_COURT[statut], valeur: compteurs[statut] || 0,
            }))
          );
          const dansUneSemaine = new Date();
          dansUneSemaine.setDate(dansUneSemaine.getDate() + 7);
          const proches = decisions
            .filter((d) => !['applique', 'abandonne'].includes(d.statut_affiche))
            .filter((d) => new Date(d.date_echeance) <= dansUneSemaine)
            .sort((a, b) => new Date(a.date_echeance) - new Date(b.date_echeance))
            .slice(0, 5);
          setEcheancesProches(proches);
          return;
        }

        const requetes = estRmo
          ? [client.get('/plans-action')]
          : [client.get('/controles'), client.get('/plans-action'), client.get('/decisions-codir')];
        const resultats = await Promise.all(requetes);
        const plans = estRmo ? resultats[0].data : resultats[1].data;
        const controles = estRmo ? null : resultats[0].data;
        const decisions = estRmo ? [] : resultats[2].data;

        setStats({
          totalControles: controles?.length,
          conformes: controles?.filter((c) => c.taux_conformite === 100).length,
          totalPlans: plans.length,
          appliques: plans.filter((p) => p.statut_affiche === 'applique').length,
          enAttente: plans.filter((p) => p.statut_affiche === 'en_attente_validation').length,
          echus: plans.filter((p) => p.statut_affiche === 'echu').length,
          decisionsEnCours: decisions.filter((d) => d.statut_affiche === 'en_cours').length,
        });

        const compteurs = {};
        plans.forEach((p) => { compteurs[p.statut_affiche] = (compteurs[p.statut_affiche] || 0) + 1; });
        setDonneesGraphique(
          Object.keys(LIBELLES_STATUT_COURT).filter((s) => s !== 'en_cours').map((statut) => ({
            statut, nom: LIBELLES_STATUT_COURT[statut], valeur: compteurs[statut] || 0,
          }))
        );

        const dansUneSemaine = new Date();
        dansUneSemaine.setDate(dansUneSemaine.getDate() + 7);
        const proches = plans
          .filter((p) => !['applique', 'abandonne'].includes(p.statut_affiche))
          .filter((p) => new Date(p.date_echeance) <= dansUneSemaine)
          .sort((a, b) => new Date(a.date_echeance) - new Date(b.date_echeance))
          .slice(0, 5);
        setEcheancesProches(proches);
      } catch (e) {
        console.error(e);
      }
    })();
  }, [estRmo, estCodir]);

  return (
    <div className="page-content">
      <div className="dashboard-header">
        <div>
          <h2 style={{ margin: '0 0 4px', fontSize: 24, fontWeight: 800 }}>Tableau de bord</h2>
          <p style={{ color: 'var(--texte-mute)', margin: 0, fontSize: 13.5 }}>
            Bienvenue {user?.prenom}, voici l'état du suivi du contrôle interne.
          </p>
        </div>
        {!estRmo && !estCodir && (
          <div style={{ display: 'flex', gap: 10 }}>
            <Link to="/fdt" className="btn btn-outline"><IconUpload width={14} height={14} /> Déposer une FDT</Link>
            <Link to="/plans-action" className="btn btn-primary"><IconPlus width={14} height={14} /> Créer un plan d'action</Link>
          </div>
        )}
        {estCodir && (
          <Link to="/decisions-codir" className="btn btn-primary"><IconPlus width={14} height={14} /> Ajouter une décision CODIR</Link>
        )}
      </div>

      {stats && estCodir && (
        <div className="dashboard-cards">
          <CarteStat label="Décisions CODIR" valeur={stats.total} lien="/decisions-codir" Icon={IconArchive} destaque />
          <CarteStat label="En cours" valeur={stats.enCours} lien="/decisions-codir" couleur="#5568b8" Icon={IconClock} />
          <CarteStat label="Appliquées" valeur={stats.appliquees} lien="/decisions-codir" couleur="#1f9d55" Icon={IconCheck} />
          <CarteStat label="Échues" valeur={stats.echues} lien="/decisions-codir" couleur="#d0342c" Icon={IconArchive} />
        </div>
      )}

      {stats && !estCodir && (
        <div className="dashboard-cards">
          <CarteStat label="Plans d'action" valeur={stats.totalPlans} lien="/plans-action" Icon={IconTrendingUp} destaque />
          {!estRmo && (
            <>
              <CarteStat label="Contrôles suivis" valeur={stats.totalControles} lien="/controles" couleur="#0e7c6b" Icon={IconShieldCheck} />
              <CarteStat label="Conformes (période en cours)" valeur={`${stats.conformes}/${stats.totalControles}`} lien="/controles" couleur="#1f9d55" Icon={IconCheck} />
            </>
          )}
          <CarteStat label="En attente de validation" valeur={stats.enAttente} lien="/plans-action" couleur="#dd9615" Icon={IconClock} />
          <CarteStat label="Échus" valeur={stats.echus} lien="/plans-action" couleur="#d0342c" Icon={IconArchive} />
          {!estRmo && (
            <CarteStat label="Décisions CODIR en cours" valeur={stats.decisionsEnCours} lien="/decisions-codir" couleur="#5568b8" Icon={IconArchive} />
          )}
        </div>
      )}

      <div className="dashboard-grid">
        <div className="card-panel" style={{ margin: 0 }}>
          <h3 className="card-title">{estCodir ? 'Répartition des décisions CODIR' : "Répartition des plans d'action"}</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={donneesGraphique} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#eef0f4" vertical={false} />
              <XAxis dataKey="nom" tick={{ fontSize: 11.5, fill: '#6b7280' }} axisLine={{ stroke: '#e2e4e8' }} tickLine={false} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11.5, fill: '#6b7280' }} axisLine={false} tickLine={false} />
              <Tooltip cursor={{ fill: '#f4f6fb' }} contentStyle={{ borderRadius: 8, border: '1px solid #e2e4e8', fontSize: 12.5 }} />
              <Bar dataKey="valeur" radius={[6, 6, 0, 0]}>
                {donneesGraphique.map((entree) => (
                  <Cell key={entree.statut} fill={COULEURS_STATUT[entree.statut]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="card-panel" style={{ margin: 0 }}>
          <h3 className="card-title">Échéances à venir</h3>
          {echeancesProches.length === 0 ? (
            <div className="empty-state" style={{ padding: 30 }}>Aucune échéance dans les 7 prochains jours.</div>
          ) : (
            <div className="reminders-list">
              {echeancesProches.map((item) => (
                <Link to={estCodir ? '/decisions-codir' : `/plans-action/${item.id}`} key={item.id} className="reminder-item">
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 13 }}>{item.code}</div>
                    <div style={{ fontSize: 12, color: 'var(--texte-mute)' }}>
                      {estCodir ? (item.intitule?.slice(0, 40) + (item.intitule?.length > 40 ? '...' : '')) : item.controle?.code}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 12, fontWeight: 600 }}>{item.date_echeance}</div>
                    <span className={`badge ${item.statut_affiche}`} style={{ fontSize: 10 }}>{LIBELLES_STATUT_COURT[item.statut_affiche]}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
          <Link to={estCodir ? '/decisions-codir' : '/plans-action'} className="btn btn-outline" style={{ width: '100%', justifyContent: 'center', marginTop: 14 }}>
            {estCodir ? 'Voir toutes les décisions CODIR' : "Voir tous les plans d'action"}
          </Link>
        </div>
      </div>
    </div>
  );
}

function CarteStat({ label, valeur, lien, couleur, Icon, destaque }) {
  if (destaque) {
    return (
      <Link to={lien} style={{ textDecoration: 'none' }}>
        <div className="card-panel dashboard-card-destaque">
          <Icon width={20} height={20} style={{ color: 'white', marginBottom: 10 }} />
          <div style={{ fontSize: 28, fontWeight: 800, color: 'white' }}>{valeur}</div>
          <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.85)', marginTop: 4, fontWeight: 600 }}>{label}</div>
        </div>
      </Link>
    );
  }
  return (
    <Link to={lien} style={{ textDecoration: 'none' }}>
      <div
        className="card-panel"
        style={{ margin: 0, borderTop: `3px solid ${couleur}`, cursor: 'pointer', transition: 'all 0.2s cubic-bezier(0.4,0,0.2,1)' }}
        onMouseEnter={(e) => { e.currentTarget.style.transform = 'translateY(-3px)'; e.currentTarget.style.boxShadow = '0 12px 28px rgba(16,24,40,0.14)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.transform = 'translateY(0)'; e.currentTarget.style.boxShadow = ''; }}
      >
        <Icon width={20} height={20} style={{ color: couleur, marginBottom: 10 }} />
        <div style={{ fontSize: 26, fontWeight: 800, color: '#1c1f26' }}>{valeur}</div>
        <div style={{ fontSize: 13, color: '#6b7280', marginTop: 4, fontWeight: 600 }}>{label}</div>
      </div>
    </Link>
  );
}
