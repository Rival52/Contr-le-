import React, { useEffect, useState } from 'react';
import client from '../api/client';
import { IconPlus, IconCheck, IconX } from '../components/Icons';

export default function Utilisateurs() {
  const [users, setUsers] = useState([]);
  const [modalOuvert, setModalOuvert] = useState(false);

  const charger = async () => {
    const { data } = await client.get('/users');
    setUsers(data);
  };

  useEffect(() => { charger(); }, []);

  const supprimer = async (id) => {
    if (!window.confirm('Confirmer la suppression de cet utilisateur ?')) return;
    await client.delete(`/users/${id}`);
    charger();
  };

  const toggleActif = async (u) => {
    await client.put(`/users/${u.id}`, { actif: !u.actif });
    charger();
  };

  return (
    <>
      <div className="page-banner" style={{ background: '#1f3a5f' }}>
        <div className="fil">Contrôle Interne / Administration</div>
        <h1>Gestion des utilisateurs</h1>
      </div>
      <div className="page-content">
        <div className="actions-bar">
          <button className="btn btn-success" onClick={() => setModalOuvert(true)}><IconPlus width={14} height={14} /> Ajouter un utilisateur</button>
        </div>

        <table className="data-table">
          <thead>
            <tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Entité</th><th>Statut</th><th></th></tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.prenom} {u.nom}</td>
                <td>{u.email}</td>
                <td><span className={`tag-role ${u.role}`}>{u.role.toUpperCase()}</span></td>
                <td>{u.entite || '-'}</td>
                <td>{u.actif ? 'Actif' : 'Désactivé'}</td>
                <td style={{ display: 'flex', gap: 8 }}>
                  <button className="btn btn-outline" onClick={() => toggleActif(u)}>
                    {u.actif ? <><IconX width={13} height={13} /> Désactiver</> : <><IconCheck width={13} height={13} /> Activer</>}
                  </button>
                  <button className="btn btn-danger" onClick={() => supprimer(u.id)}><IconX width={13} height={13} /> Supprimer</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {modalOuvert && (
        <ModalCreationUser onClose={() => setModalOuvert(false)} onCreated={() => { setModalOuvert(false); charger(); }} />
      )}
    </>
  );
}

function ModalCreationUser({ onClose, onCreated }) {
  const [form, setForm] = useState({ nom: '', prenom: '', email: '', password: '', role: 'rmo', entite: '' });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.post('/users', form);
      onCreated();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la création.');
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>Ajouter un utilisateur</h3>
        {erreur && <div style={{ color: '#b02b2b', marginBottom: 10 }}>{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid">
            <div><label>Prénom</label><input required value={form.prenom} onChange={(e) => setForm({ ...form, prenom: e.target.value })} /></div>
            <div><label>Nom</label><input required value={form.nom} onChange={(e) => setForm({ ...form, nom: e.target.value })} /></div>
          </div>
          <div className="form-grid full">
            <div><label>Email</label><input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          </div>
          <div className="form-grid">
            <div><label>Mot de passe</label><input required type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <div>
              <label>Rôle</label>
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                <option value="rmo">RMO</option>
                <option value="controleur">Contrôleur</option>
                <option value="codir">CODIR</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>
          <div className="form-grid full">
            <div><label>Entité</label><input value={form.entite} onChange={(e) => setForm({ ...form, entite: e.target.value })} /></div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Création...' : 'Créer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
