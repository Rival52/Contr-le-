import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import client, { telechargerFichier } from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconPlus, IconDownload } from '../components/Icons';

const LIBELLES_STATUT = {
  non_echu: 'Non échu',
  en_attente_validation: 'En attente de validation',
  refuse: 'Refusé',
  applique: 'Appliqué',
  echu: 'Échu',
  abandonne: 'Abandonné',
};

export default function PlansActionListe() {
  const { user } = useAuth();
  const [plans, setPlans] = useState([]);
  const [statutFiltre, setStatutFiltre] = useState('');
  const [chargement, setChargement] = useState(false);
  const [modalOuvert, setModalOuvert] = useState(false);

  const peutCreer = user?.role === 'admin' || user?.role === 'controleur';

  const charger = async () => {
    setChargement(true);
    try {
      const params = {};
      if (statutFiltre) params.statut = statutFiltre;
      const { data } = await client.get('/plans-action', { params });
      setPlans(data);
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => { charger(); }, []); // eslint-disable-line

  const handleExport = () => {
    telechargerFichier('/plans-action/export/excel', 'liste_plans_action.xlsx');
  };

  return (
    <>
      <div className="page-banner plan-action">
        <div className="fil">Contrôle Interne / Plans d'action</div>
        <h1>Liste des plans d'action</h1>
      </div>
      <div className="page-content">
        <div className="filtre-panel">
          <div className="filtre-titre">Critères de filtre</div>
          <div className="filtre-grid">
            <div>
              <label>Statut</label>
              <select value={statutFiltre} onChange={(e) => setStatutFiltre(e.target.value)}>
                <option value="">-- Tous --</option>
                {Object.entries(LIBELLES_STATUT).map(([k, v]) => (
                  <option key={k} value={k}>{v}</option>
                ))}
              </select>
            </div>
          </div>
          <button className="btn-appliquer" onClick={charger}>Appliquer</button>
        </div>

        <div className="actions-bar">
          <button className="btn btn-outline" onClick={handleExport}><IconDownload width={14} height={14} /> Excel - liste des plans d'action</button>
          {peutCreer && (
            <button className="btn btn-success" onClick={() => setModalOuvert(true)}><IconPlus width={14} height={14} /> Créer un plan d'action</button>
          )}
        </div>

        {chargement ? (
          <p>Chargement...</p>
        ) : plans.length === 0 ? (
          <div className="empty-state">Aucun plan d'action trouvé.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Contrôle</th>
                <th>Recommandation</th>
                <th>RMO</th>
                <th>Échéance</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {plans.map((p) => (
                <tr key={p.id}>
                  <td><Link to={`/plans-action/${p.id}`}>{p.code}</Link></td>
                  <td>{p.controle?.code}</td>
                  <td>{p.recommandation?.slice(0, 80)}{p.recommandation?.length > 80 ? '…' : ''}</td>
                  <td>{p.rmo ? `${p.rmo.prenom} ${p.rmo.nom}` : '-'}</td>
                  <td>{p.date_echeance}</td>
                  <td><span className={`badge ${p.statut_affiche}`}>{LIBELLES_STATUT[p.statut_affiche]}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {modalOuvert && (
        <ModalCreationPlan onClose={() => setModalOuvert(false)} onCreated={() => { setModalOuvert(false); charger(); }} />
      )}
    </>
  );
}

function ModalCreationPlan({ onClose, onCreated }) {
  const [rmos, setRmos] = useState([]);
  const [form, setForm] = useState({ controle_code: '', recommandation: '', rmo_id: '', date_echeance: '' });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);

  useEffect(() => {
    client.get('/users').then(({ data }) => setRmos(data.filter((u) => u.role === 'rmo')));
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.post('/plans-action', form);
      onCreated();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la création.');
    } finally {
      setEnvoi(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <h3>Créer un plan d'action</h3>
        {erreur && <div className="erreur" style={{ color: '#b02b2b', marginBottom: 10 }}>{erreur}</div>}
        <form onSubmit={submit}>
          <div className="form-grid full">
            <div>
              <label>Code de contrôle associé</label>
              <input required value={form.controle_code} onChange={(e) => setForm({ ...form, controle_code: e.target.value })} placeholder="Ex : C31048" />
            </div>
          </div>
          <div className="form-grid full">
            <div>
              <label>Recommandation</label>
              <textarea required rows={4} value={form.recommandation} onChange={(e) => setForm({ ...form, recommandation: e.target.value })} />
            </div>
          </div>
          <div className="form-grid">
            <div>
              <label>RMO concerné</label>
              <select required value={form.rmo_id} onChange={(e) => setForm({ ...form, rmo_id: e.target.value })}>
                <option value="">-- Sélectionner --</option>
                {rmos.map((r) => (
                  <option key={r.id} value={r.id}>{r.prenom} {r.nom}</option>
                ))}
              </select>
            </div>
            <div>
              <label>Date d'échéance</label>
              <input required type="date" value={form.date_echeance} onChange={(e) => setForm({ ...form, date_echeance: e.target.value })} />
            </div>
          </div>
          <div className="modal-close-row">
            <button type="button" className="btn btn-outline" onClick={onClose}>Annuler</button>
            <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Création...' : 'Créer'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}
