import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../api/AuthContext';
import logo from '../assets/logo.png';
import bg from '../assets/login-bg.png';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [erreur, setErreur] = useState('');
  const [chargement, setChargement] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErreur('');
    setChargement(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur de connexion.');
    } finally {
      setChargement(false);
    }
  };

  return (
    <div className="login-page-v2">
      <div className="login-card-v2">
        <form className="login-form-panel" onSubmit={handleSubmit}>
          <div className="login-brand-row">
            <img src={logo} alt="Logo" className="login-logo-sm" />
            <span className="brand-name" style={{ fontSize: 19 }}>OPTIKA</span>
          </div>

          <h1>Connexion</h1>
          <p className="login-sous-titre">Accédez à votre espace Contrôle Interne</p>

          {erreur && <div className="erreur">{erreur}</div>}

          <label className="login-label">Adresse email</label>
          <input
            type="email"
            placeholder="nom@bgfi.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label className="login-label">Mot de passe</label>
          <input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <button type="submit" disabled={chargement}>
            {chargement ? 'Connexion...' : 'Se connecter'}
          </button>

          <Link to="/mot-de-passe-oublie" className="login-lien-secondaire">
            Mot de passe oublié ?
          </Link>
        </form>

        <div className="login-image-panel" style={{ backgroundImage: `url(${bg})` }}>
          <div className="login-image-overlay" />
          <div className="login-pill-badge">
            <span className="login-pill-dot" />
            OPTIKA · Contrôle Interne
          </div>
          <div className="login-tag-bottom">
            Plateforme de suivi des contrôles, plans d'action et décisions CODIR
          </div>
        </div>
      </div>
    </div>
  );
}
