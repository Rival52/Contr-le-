import React, { useEffect, useRef, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import client from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconCheck, IconX, IconArchive, IconUpload, IconDownload } from '../components/Icons';

const LIBELLES_STATUT = {
  non_echu: 'Non échu',
  en_attente_validation: 'En attente de validation',
  applique: 'Appliqué',
  echu: 'Échu',
  abandonne: 'Abandonné',
};

export default function PlanActionDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [plan, setPlan] = useState(null);
  const [commentaireFichier, setCommentaireFichier] = useState('');
  const [commentaireRefus, setCommentaireRefus] = useState('');
  const [afficherRefus, setAfficherRefus] = useState(false);
  const fileInputRef = useRef(null);

  const estControleur = user?.role === 'admin' || user?.role === 'controleur';
  const estRmoConcerne = user?.role === 'rmo' && plan?.rmo_id === user.id;

  const charger = async () => {
    try {
      const { data } = await client.get(`/plans-action/${id}`);
      setPlan(data);
    } catch (err) {
      navigate('/plans-action');
    }
  };

  useEffect(() => { charger(); }, [id]); // eslint-disable-line

  const handleUploadClick = () => fileInputRef.current?.click();

  const handleUploadJustificatif = async (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;
    const formData = new FormData();
    formData.append('fichier', fichier);
    formData.append('commentaire', commentaireFichier);
    await client.post(`/plans-action/${id}/justificatif`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    setCommentaireFichier('');
    e.target.value = '';
    charger();
  };

  const valider = async () => {
    await client.put(`/plans-action/${id}/valider`);
    charger();
  };

  const refuser = async () => {
    if (!commentaireRefus.trim()) return;
    await client.put(`/plans-action/${id}/refuser`, { commentaire_refus: commentaireRefus });
    setCommentaireRefus('');
    setAfficherRefus(false);
    charger();
  };

  const abandonner = async () => {
    if (!window.confirm('Confirmer l\'abandon de ce plan d\'action ?')) return;
    await client.put(`/plans-action/${id}/abandonner`);
    charger();
  };

  const telechargerJustificatif = (justifId) => {
    window.open(`${client.defaults.baseURL}/plans-action/justificatif/${justifId}/download`, '_blank');
  };

  if (!plan) return <div className="page-content">Chargement...</div>;

  const statut = plan.statut_affiche;
  const estClos = ['applique', 'abandonne'].includes(statut);

  return (
    <>
      <div className="page-banner plan-action">
        <div className="fil"><Link to="/plans-action" style={{ color: 'white' }}>Plans d'action</Link> / {plan.code}</div>
        <h1>{plan.code}</h1>
      </div>
      <div className="page-content">
        <div style={{ background: 'white', border: '1px solid #e2e4e8', borderRadius: 6, padding: 20, marginBottom: 20 }}>
          <div className="form-grid">
            <div><label>Contrôle associé</label><div>{plan.controle?.code} — {plan.controle?.processus}</div></div>
            <div><label>Statut</label><div><span className={`badge ${statut}`}>{LIBELLES_STATUT[statut]}</span></div></div>
            <div><label>RMO responsable</label><div>{plan.rmo ? `${plan.rmo.prenom} ${plan.rmo.nom}` : '-'}</div></div>
            <div><label>Contrôleur</label><div>{plan.controleur ? `${plan.controleur.prenom} ${plan.controleur.nom}` : '-'}</div></div>
            <div><label>Date d'échéance</label><div>{plan.date_echeance}</div></div>
          </div>
          <div style={{ marginTop: 10 }}>
            <label style={{ fontSize: 12, color: '#555' }}>Recommandation</label>
            <div>{plan.recommandation}</div>
          </div>
          {plan.commentaire_refus && (
            <div style={{ marginTop: 14, padding: 12, background: '#fdecec', borderRadius: 4, border: '1px solid #f3c2c2' }}>
              <strong>Dernier commentaire de refus :</strong> {plan.commentaire_refus}
            </div>
          )}
        </div>

        {estControleur && !estClos && (
          <div style={{ background: 'white', border: '1px solid #e2e4e8', borderRadius: 6, padding: 20, marginBottom: 20 }}>
            <h4 style={{ marginTop: 0 }}>Actions du contrôleur</h4>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
              <button className="btn btn-success" onClick={valider} disabled={statut !== 'en_attente_validation'}>
                <IconCheck width={14} height={14} /> Valider l'action
              </button>
              <button className="btn btn-outline" onClick={() => setAfficherRefus(!afficherRefus)} disabled={statut !== 'en_attente_validation'}>
                <IconX width={14} height={14} /> Refuser l'action
              </button>
              <button className="btn btn-danger" onClick={abandonner}>
                <IconArchive width={14} height={14} /> Abandonner le plan
              </button>
            </div>
            {statut !== 'en_attente_validation' && (
              <p style={{ fontSize: 12, color: '#888', marginTop: 8 }}>
                La validation/refus n'est possible que lorsqu'une action a été soumise par le RMO.
              </p>
            )}
            {afficherRefus && (
              <div style={{ marginTop: 14 }}>
                <label style={{ fontSize: 12, color: '#555' }}>Motif du refus (obligatoire)</label>
                <textarea rows={3} value={commentaireRefus} onChange={(e) => setCommentaireRefus(e.target.value)} style={{ width: '100%', padding: 8, border: '1px solid #e2e4e8', borderRadius: 4 }} />
                <button className="btn btn-danger" style={{ marginTop: 8 }} onClick={refuser}>Confirmer le refus</button>
              </div>
            )}
          </div>
        )}

        <div style={{ background: 'white', border: '1px solid #e2e4e8', borderRadius: 6, padding: 20 }}>
          <h4 style={{ marginTop: 0 }}>Fichiers d'action</h4>

          {estRmoConcerne && !estClos && (
            <div style={{ marginBottom: 16, paddingBottom: 16, borderBottom: '1px solid #eee' }}>
              <label style={{ fontSize: 12, color: '#555' }}>Commentaire (optionnel)</label>
              <input
                value={commentaireFichier}
                onChange={(e) => setCommentaireFichier(e.target.value)}
                style={{ width: '100%', padding: 8, border: '1px solid #e2e4e8', borderRadius: 4, marginBottom: 10 }}
              />
              <input type="file" ref={fileInputRef} style={{ display: 'none' }} onChange={handleUploadJustificatif} />
              <button className="btn btn-success" onClick={handleUploadClick}><IconUpload width={14} height={14} /> Ajouter mon fichier d'action</button>
            </div>
          )}

          {(!plan.justificatifs || plan.justificatifs.length === 0) ? (
            <div className="empty-state">Aucun fichier soumis pour le moment.</div>
          ) : (
            <table className="data-table">
              <thead><tr><th>Fichier</th><th>Commentaire</th><th></th></tr></thead>
              <tbody>
                {plan.justificatifs.map((j) => (
                  <tr key={j.id}>
                    <td>{j.nom_fichier}</td>
                    <td>{j.commentaire || '-'}</td>
                    <td><button className="btn btn-outline" onClick={() => telechargerJustificatif(j.id)}><IconDownload width={13} height={13} /> Télécharger</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
