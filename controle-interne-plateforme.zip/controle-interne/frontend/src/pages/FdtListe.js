import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import client from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconUpload, IconDownload, IconPlus } from '../components/Icons';

export default function FdtListe() {
  const { user } = useAuth();
  const [fdts, setFdts] = useState([]);
  const [controleCodes, setControleCodes] = useState('');
  const [message, setMessage] = useState(null);
  const [envoi, setEnvoi] = useState(false);
  const [derniereFdt, setDerniereFdt] = useState(null);
  const fileInputRef = useRef(null);
  const peutGerer = user?.role === 'admin' || user?.role === 'controleur';

  const charger = async () => {
    const { data } = await client.get('/fdt');
    setFdts(data);
  };

  useEffect(() => { charger(); }, []);

  const handleUploadClick = () => {
    if (!controleCodes.trim()) {
      setMessage({ type: 'erreur', texte: 'Indiquez au moins un code de contrôle (séparés par une virgule).' });
      return;
    }
    fileInputRef.current?.click();
  };

  const handleFichier = async (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;
    setEnvoi(true);
    setMessage(null);
    setDerniereFdt(null);
    const formData = new FormData();
    formData.append('fichier', fichier);
    formData.append('controle_codes', controleCodes.trim());
    try {
      const { data } = await client.post('/fdt', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      const ajoutes = data.resultats.filter((r) => r.statut === 'ajoute');
      const dejaCouverts = data.resultats.filter((r) => r.statut === 'deja_couvert');
      let texte = `FDT ${data.code} déposée.`;
      if (ajoutes.length) texte += ` Contrôle(s) validé(s) à 100% : ${ajoutes.map((r) => `${r.code} (${r.periode})`).join(', ')}.`;
      if (dejaCouverts.length) texte += ` Déjà couvert(s) pour la période : ${dejaCouverts.map((r) => r.code).join(', ')}.`;
      setMessage({ type: 'succes', texte });
      setDerniereFdt(data);
      setControleCodes('');
      charger();
    } catch (err) {
      setMessage({ type: 'erreur', texte: err.response?.data?.message || 'Erreur lors du dépôt de la FDT.' });
    } finally {
      setEnvoi(false);
      e.target.value = '';
    }
  };

  const telecharger = (id) => {
    window.open(`${client.defaults.baseURL}/fdt/${id}/download`, '_blank');
  };

  return (
    <>
      <div className="page-banner controle">
        <div className="fil">OPTIKA / Feuilles de travail</div>
        <h1>Feuilles de travail (FDT)</h1>
      </div>
      <div className="page-content">
        {peutGerer && (
          <div className="card-panel">
            <h3 className="card-title">Déposer une FDT signée</h3>
            <div className="upload-row">
              <div className="upload-field">
                <label>Code(s) de contrôle couvert(s)</label>
                <input
                  value={controleCodes}
                  onChange={(e) => setControleCodes(e.target.value)}
                  placeholder="Ex : C31048, C65905, C74083"
                />
              </div>
              <input type="file" ref={fileInputRef} accept="application/pdf" style={{ display: 'none' }} onChange={handleFichier} />
              <button className="btn btn-success" onClick={handleUploadClick} disabled={envoi}>
                <IconUpload width={15} height={15} /> {envoi ? 'Envoi...' : 'Importer le PDF signé'}
              </button>
            </div>
            {message && (
              <div className={`inline-alert ${message.type === 'succes' ? 'inline-alert-success' : 'inline-alert-error'}`}>
                {message.texte}
              </div>
            )}

            {derniereFdt && (
              <CreationPlanActionInline
                codesDisponibles={derniereFdt.controles.map((c) => c.code)}
                onCreated={() => setDerniereFdt(null)}
              />
            )}
          </div>
        )}

        {fdts.length === 0 ? (
          <div className="empty-state">Aucune FDT déposée pour le moment.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code FDT</th>
                <th>Contrôles couverts</th>
                <th>Déposée par</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {fdts.map((f) => (
                <tr key={f.id}>
                  <td style={{ fontWeight: 700, color: 'var(--controle)' }}>{f.code}</td>
                  <td>
                    {f.controles.map((c) => (
                      <span key={c.id} className="chip">
                        <Link to={`/controles/${c.id}`}>{c.code}</Link>
                        <span className="chip-sub">{c.periode_libelle}</span>
                      </span>
                    ))}
                  </td>
                  <td>{f.auteur ? `${f.auteur.prenom} ${f.auteur.nom}` : '-'}</td>
                  <td>
                    <button className="btn btn-outline btn-sm" onClick={() => telecharger(f.id)}>
                      <IconDownload width={13} height={13} /> Télécharger
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

function CreationPlanActionInline({ codesDisponibles, onCreated }) {
  const [ouvert, setOuvert] = useState(false);
  const [rmos, setRmos] = useState([]);
  const [form, setForm] = useState({ controle_code: codesDisponibles[0] || '', recommandation: '', rmo_id: '', date_echeance: '' });
  const [erreur, setErreur] = useState('');
  const [envoi, setEnvoi] = useState(false);
  const [succes, setSucces] = useState(false);

  useEffect(() => {
    if (ouvert) client.get('/users').then(({ data }) => setRmos(data.filter((u) => u.role === 'rmo')));
  }, [ouvert]);

  const submit = async (e) => {
    e.preventDefault();
    setErreur('');
    setEnvoi(true);
    try {
      await client.post('/plans-action', form);
      setSucces(true);
      onCreated();
    } catch (err) {
      setErreur(err.response?.data?.message || 'Erreur lors de la création.');
    } finally {
      setEnvoi(false);
    }
  };

  if (succes) {
    return <div className="inline-alert inline-alert-success">Plan d'action créé — il est visible dans la liste des plans d'action.</div>;
  }

  if (!ouvert) {
    return (
      <button className="btn btn-outline" style={{ marginTop: 14 }} onClick={() => setOuvert(true)}>
        <IconPlus width={14} height={14} /> Créer un plan d'action pour un de ces contrôles
      </button>
    );
  }

  return (
    <form onSubmit={submit} className="inline-form">
      {erreur && <div className="inline-alert inline-alert-error">{erreur}</div>}
      <div className="form-grid">
        <div>
          <label>Code de contrôle</label>
          <select value={form.controle_code} onChange={(e) => setForm({ ...form, controle_code: e.target.value })}>
            {codesDisponibles.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        <div>
          <label>RMO concerné</label>
          <select required value={form.rmo_id} onChange={(e) => setForm({ ...form, rmo_id: e.target.value })}>
            <option value="">-- Sélectionner --</option>
            {rmos.map((r) => <option key={r.id} value={r.id}>{r.prenom} {r.nom}</option>)}
          </select>
        </div>
      </div>
      <div className="form-grid full">
        <div>
          <label>Recommandation</label>
          <textarea required rows={3} value={form.recommandation} onChange={(e) => setForm({ ...form, recommandation: e.target.value })} />
        </div>
      </div>
      <div className="form-grid">
        <div>
          <label>Date d'échéance</label>
          <input required type="date" value={form.date_echeance} onChange={(e) => setForm({ ...form, date_echeance: e.target.value })} />
        </div>
      </div>
      <div className="modal-close-row">
        <button type="button" className="btn btn-outline" onClick={() => setOuvert(false)}>Annuler</button>
        <button type="submit" className="btn btn-success" disabled={envoi}>{envoi ? 'Création...' : 'Créer le plan d\'action'}</button>
      </div>
    </form>
  );
}
