import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import client from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconUpload, IconDownload, IconFile } from '../components/Icons';

export default function FdtListe() {
  const { user } = useAuth();
  const [fdts, setFdts] = useState([]);
  const [controleCode, setControleCode] = useState('');
  const [message, setMessage] = useState(null);
  const [envoi, setEnvoi] = useState(false);
  const fileInputRef = useRef(null);
  const peutGerer = user?.role === 'admin' || user?.role === 'controleur';

  const charger = async () => {
    const { data } = await client.get('/fdt');
    setFdts(data);
  };

  useEffect(() => { charger(); }, []);

  const handleUploadClick = () => {
    if (!controleCode.trim()) {
      setMessage({ type: 'erreur', texte: "Indiquez d'abord le code de contrôle concerné." });
      return;
    }
    fileInputRef.current?.click();
  };

  const handleFichier = async (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;
    setEnvoi(true);
    setMessage(null);
    const formData = new FormData();
    formData.append('fichier', fichier);
    formData.append('controle_code', controleCode.trim());
    try {
      const { data } = await client.post('/fdt', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      setMessage({ type: 'succes', texte: `FDT ${data.code} déposée pour la période ${data.periode_libelle}. Le contrôle passe à 100% de conformité.` });
      setControleCode('');
      charger();
    } catch (err) {
      setMessage({ type: 'erreur', texte: err.response?.data?.message || 'Erreur lors du dépôt de la FDT.' });
    } finally {
      setEnvoi(false);
      e.target.value = '';
    }
  };

  const telecharger = (id) => {
    window.open(`${client.defaults.baseURL}/fdt/${id}/download`, '_blank');
  };

  return (
    <>
      <div className="page-banner controle">
        <div className="fil">OPTIKA / Feuilles de travail</div>
        <h1>Feuilles de travail (FDT)</h1>
      </div>
      <div className="page-content">
        {peutGerer && (
          <div className="card-panel">
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
              <IconFile width={18} height={18} style={{ color: 'var(--controle)' }} />
              <h3 style={{ margin: 0, fontSize: 15 }}>Déposer une FDT signée</h3>
            </div>
            <p style={{ color: 'var(--texte-mute)', fontSize: 13, marginTop: 0, marginBottom: 16 }}>
              Importez le PDF signé de la feuille de travail. Le code de contrôle qu'elle porte permet à la
              plateforme de reconnaître automatiquement que le contrôle a été réalisé pour la période en cours —
              son taux de conformité passera à <strong>100%</strong> ; sans dépôt, il reste à <strong>0%</strong>.
            </p>
            <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <div style={{ flex: '1 1 220px' }}>
                <label style={{ display: 'block', fontSize: 12, color: 'var(--texte-mute)', marginBottom: 5, fontWeight: 600 }}>
                  Code de contrôle
                </label>
                <input
                  value={controleCode}
                  onChange={(e) => setControleCode(e.target.value)}
                  placeholder="Ex : C31048"
                  style={{ width: '100%', padding: '9px 11px', border: '1px solid var(--bordure)', borderRadius: 8, fontSize: 13.5 }}
                />
              </div>
              <input type="file" ref={fileInputRef} accept="application/pdf" style={{ display: 'none' }} onChange={handleFichier} />
              <button className="btn btn-success" onClick={handleUploadClick} disabled={envoi}>
                <IconUpload width={15} height={15} /> {envoi ? 'Envoi...' : 'Importer le PDF signé'}
              </button>
            </div>
            {message && (
              <div style={{
                marginTop: 14, padding: '10px 14px', borderRadius: 8, fontSize: 13,
                background: message.type === 'succes' ? 'var(--succes-soft)' : 'var(--danger-soft)',
                color: message.type === 'succes' ? 'var(--succes)' : 'var(--danger)',
                fontWeight: 600,
              }}>
                {message.texte}
              </div>
            )}
          </div>
        )}

        {fdts.length === 0 ? (
          <div className="empty-state">Aucune FDT déposée pour le moment.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code FDT</th>
                <th>Contrôle</th>
                <th>Période</th>
                <th>Déposée par</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {fdts.map((f) => (
                <tr key={f.id}>
                  <td style={{ fontWeight: 700, color: 'var(--controle)' }}>{f.code}</td>
                  <td><Link to={`/controles/${f.controle?.id}`}>{f.controle?.code}</Link> — {f.controle?.processus}</td>
                  <td>{f.periode_libelle}</td>
                  <td>{f.auteur ? `${f.auteur.prenom} ${f.auteur.nom}` : '-'}</td>
                  <td>
                    <button className="btn btn-outline btn-sm" onClick={() => telecharger(f.id)}>
                      <IconDownload width={13} height={13} /> Télécharger
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
