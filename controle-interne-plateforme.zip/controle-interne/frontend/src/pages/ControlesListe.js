import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import client, { telechargerFichier } from '../api/client';
import { useAuth } from '../api/AuthContext';
import { IconDownload, IconUpload, IconSearch } from '../components/Icons';

export default function ControlesListe() {
  const { user } = useAuth();
  const [controles, setControles] = useState([]);
  const [filtres, setFiltres] = useState({ periodicite: '', processus: '' });
  const [recherche, setRecherche] = useState('');
  const [chargement, setChargement] = useState(false);
  const [message, setMessage] = useState('');
  const fileInputRef = useRef(null);

  const peutGerer = user?.role === 'admin' || user?.role === 'controleur';

  const charger = async () => {
    setChargement(true);
    try {
      const params = {};
      if (filtres.periodicite) params.periodicite = filtres.periodicite;
      if (filtres.processus) params.processus = filtres.processus;
      const { data } = await client.get('/controles', { params });
      setControles(data);
    } finally {
      setChargement(false);
    }
  };

  useEffect(() => { charger(); }, []); // eslint-disable-line

  const controlesFiltres = controles.filter((c) => {
    if (filtres.code && !c.code?.toLowerCase().includes(filtres.code.toLowerCase())) return false;
    if (!recherche.trim()) return true;
    const q = recherche.toLowerCase();
    return (
      c.code?.toLowerCase().includes(q) ||
      c.processus?.toLowerCase().includes(q) ||
      c.activite?.toLowerCase().includes(q)
    );
  });

  const processusDisponibles = [...new Set(controles.map((c) => c.processus).filter(Boolean))].sort();

  const handleExport = () => {
    telechargerFichier('/controles/export/excel', 'programme_controle.xlsx');
  };

  const handleImportClick = () => fileInputRef.current?.click();

  const handleImportFile = async (e) => {
    const fichier = e.target.files[0];
    if (!fichier) return;
    const formData = new FormData();
    formData.append('fichier', fichier);
    setMessage('Import en cours...');
    try {
      const { data } = await client.post('/controles/import/excel', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      let texte = `Feuille "${data.feuille_utilisee}" : ${data.crees} créé(s), ${data.mis_a_jour} mis à jour.`;
      if (data.ignores) texte += ` ${data.ignores} ligne(s) ignorée(s) (code invalide ou vide).`;
      setMessage(texte);
      charger();
    } catch (err) {
      setMessage(err.response?.data?.message || "Erreur lors de l'import.");
    } finally {
      e.target.value = '';
    }
  };

  return (
    <>
      <div className="page-banner controle">
        <div className="fil">Contrôle Interne / Contrôles</div>
        <h1>Liste des contrôles</h1>
      </div>
      <div className="page-content">
        <div className="filtre-panel">
          <div className="filtre-titre">Critères de filtre</div>
          <div className="filtre-grid">
            <div>
              <label>Périodicité</label>
              <select value={filtres.periodicite} onChange={(e) => setFiltres({ ...filtres, periodicite: e.target.value })}>
                <option value="">-- Toutes --</option>
                <option>Hebdomadaire</option>
                <option>Mensuelle</option>
                <option>Trimestrielle</option>
                <option>Semestrielle</option>
                <option>Annuelle</option>
              </select>
            </div>
            <div>
              <label>Processus</label>
              <select value={filtres.processus} onChange={(e) => setFiltres({ ...filtres, processus: e.target.value })}>
                <option value="">-- Tous --</option>
                {processusDisponibles.map((p) => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <label>Code de contrôle</label>
              <input
                value={filtres.code || ''}
                onChange={(e) => setFiltres({ ...filtres, code: e.target.value })}
                placeholder="Ex : C31048"
              />
            </div>
          </div>
          <button className="btn-appliquer" onClick={charger}>Appliquer</button>
        </div>

        <div className="actions-bar">
          <div className="search-box">
            <IconSearch width={15} height={15} />
            <input
              placeholder="Rechercher un code, un processus..."
              value={recherche}
              onChange={(e) => setRecherche(e.target.value)}
            />
          </div>
          {message && <span style={{ fontSize: 13, color: 'var(--succes)', fontWeight: 600 }}>{message}</span>}
          <button className="btn btn-outline" onClick={handleExport}><IconDownload width={14} height={14} /> Excel - liste des contrôles</button>
          {peutGerer && (
            <>
              <input type="file" ref={fileInputRef} style={{ display: 'none' }} accept=".xlsx,.xls" onChange={handleImportFile} />
              <button className="btn btn-success" onClick={handleImportClick}><IconUpload width={14} height={14} /> Importer un fichier Excel</button>
            </>
          )}
        </div>

        {chargement ? (
          <p>Chargement...</p>
        ) : controlesFiltres.length === 0 ? (
          <div className="empty-state">Aucun contrôle trouvé.</div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Code</th>
                <th>Processus</th>
                <th>Activité</th>
                <th>Sources</th>
                <th>Périodicité</th>
                <th>Responsable</th>
                <th>Taux conformité</th>
              </tr>
            </thead>
            <tbody>
              {controlesFiltres.map((c) => (
                <tr key={c.id}>
                  <td><Link to={`/controles/${c.id}`}>{c.code}</Link></td>
                  <td>{c.processus}</td>
                  <td>{c.activite}</td>
                  <td>{c.sources}</td>
                  <td>{c.periodicite}</td>
                  <td>{c.responsable ? `${c.responsable.prenom} ${c.responsable.nom}` : '-'}</td>
                  <td>{c.taux_conformite != null ? `${c.taux_conformite}%` : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}
