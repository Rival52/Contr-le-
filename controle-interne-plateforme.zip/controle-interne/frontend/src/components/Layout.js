import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../api/AuthContext';
import logo from '../assets/logo.png';
import { IconHome, IconShieldCheck, IconFile, IconTrendingUp, IconUsers, IconChevronDown, IconLogOut } from './Icons';

const libellesModule = {
  controle: 'Contrôle',
  'plan-action': "Plans d'action",
};

const NAV_ITEMS_GERANT = [
  { to: '/', label: 'Accueil', Icon: IconHome },
  { to: '/controles', label: 'Contrôles', Icon: IconShieldCheck },
  { to: '/fdt', label: 'Feuilles de travail', Icon: IconFile },
  { to: '/plans-action', label: "Plans d'action", Icon: IconTrendingUp },
];

const NAV_ITEMS_RMO = [
  { to: '/', label: 'Accueil', Icon: IconHome },
  { to: '/plans-action', label: "Plans d'action", Icon: IconTrendingUp },
];

export default function Layout({ children, module }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [menuOuvert, setMenuOuvert] = useState(false);
  const initiales = user ? `${user.prenom?.[0] || ''}${user.nom?.[0] || ''}`.toUpperCase() : '';

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const isActive = (to) => (to === '/' ? location.pathname === '/' : location.pathname.startsWith(to));

  return (
    <div className="app-shell">
      <div className="topbar">
        <div className="topbar-left">
          <Link to="/" className="brand">
            <img src={logo} alt="Logo" className="topbar-logo" />
            <span className="brand-name">OPTIKA</span>
          </Link>
          {module && (
            <span className={`topbar-module ${module}`}>
              Module {libellesModule[module]}
            </span>
          )}
        </div>

        <nav className="topbar-nav">
          {(user?.role === 'rmo' ? NAV_ITEMS_RMO : NAV_ITEMS_GERANT).map(({ to, label, Icon }) => (
            <Link key={to} to={to} className={isActive(to) ? 'active' : ''}>
              <Icon className="nav-icon" />{label}
            </Link>
          ))}
          {user?.role === 'admin' && (
            <Link to="/utilisateurs" className={isActive('/utilisateurs') ? 'active' : ''}>
              <IconUsers className="nav-icon" />Utilisateurs
            </Link>
          )}
        </nav>

        <div className="topbar-user" onClick={() => setMenuOuvert(!menuOuvert)}>
          <div className="avatar">{initiales}</div>
          <span className="user-name">{user?.prenom} {user?.nom}</span>
          <IconChevronDown className={`chevron ${menuOuvert ? 'open' : ''}`} width={16} height={16} />

          {menuOuvert && (
            <div className="user-menu" onClick={(e) => e.stopPropagation()}>
              <div className="user-menu-header">
                <div className="avatar avatar-lg">{initiales}</div>
                <div>
                  <div style={{ fontWeight: 700 }}>{user?.prenom} {user?.nom}</div>
                  <span className={`tag-role ${user?.role}`}>{user?.role?.toUpperCase()}</span>
                </div>
              </div>
              <button className="user-menu-logout" onClick={handleLogout}>
                <IconLogOut width={15} height={15} /> Déconnexion
              </button>
            </div>
          )}
        </div>
      </div>
      <div className="page-transition">{children}</div>
    </div>
  );
}
