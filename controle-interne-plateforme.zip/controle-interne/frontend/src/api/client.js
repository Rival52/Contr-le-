import axios from 'axios';

const client = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// window.open()/téléchargement direct par URL ne passe PAS par l'intercepteur ci-dessus
// (ce n'est pas une requête axios), donc le token JWT n'est jamais envoyé -> 401.
// On télécharge donc le fichier via axios (avec le header Authorization), puis on le
// convertit en blob local pour déclencher le téléchargement dans le navigateur.
export async function telechargerFichier(path, nomParDefaut) {
  const res = await client.get(path, { responseType: 'blob' });
  let nomFichier = nomParDefaut;
  const disposition = res.headers['content-disposition'];
  if (disposition) {
    const match = disposition.match(/filename="?([^"';]+)"?/);
    if (match) nomFichier = match[1];
  }
  const blob = new Blob([res.data]);
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = nomFichier || 'fichier';
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(url);
}

export default client;
