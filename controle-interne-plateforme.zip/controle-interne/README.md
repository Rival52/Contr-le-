# Plateforme Contrôle Interne

Application interne de gestion du contrôle interne : contrôles, fiches de travail (FDT),
plans d'action, avec 3 rôles (Admin, Contrôleur, RMO).

## Structure du projet

```
controle-interne/
├── backend/     API Node.js / Express + PostgreSQL
└── frontend/    Application React (single page app)
```

## Fonctionnalités

- **Authentification par rôle**
  - **Admin** : gère les comptes utilisateurs (seul rôle pouvant créer/supprimer des utilisateurs). Jusqu'à 30 utilisateurs et plus, aucune limite technique.
  - **Contrôleur** : tous les droits fonctionnels (contrôles, FDT, plans d'action) sauf la gestion des utilisateurs.
  - **RMO** : consulte les contrôles, consulte ses plans d'action assignés, ajoute ses fichiers d'action.
- **Module Contrôle** : import/export Excel des contrôles (colonnes : Code, Processus, Activité, Risques,
  Contrôles, Sources, Support requis, Périodicité, Dates).
- **Module FDT (Feuille de Travail)** : le contrôleur dépose le **PDF signé** de la FDT en indiquant le
  **code de contrôle** concerné. La plateforme calcule automatiquement la période en cours selon la
  périodicité du contrôle (hebdomadaire/mensuelle/trimestrielle/semestrielle/annuelle) : si une FDT existe
  pour cette période, le contrôle affiche **100%** de conformité, sinon **0%**. Le PDF reste téléchargeable
  à tout moment depuis la fiche du contrôle ou la liste des FDT.
- **Module Plan d'action** : le contrôleur crée un plan d'action à partir d'un **code de contrôle** +
  une recommandation, l'assigne à un RMO avec une date d'échéance. Le RMO soumet son fichier d'action ;
  le contrôleur valide (statut "Appliqué") ou refuse (avec commentaire obligatoire, le plan repasse en cours).
  Le contrôleur peut aussi abandonner un plan. Le statut "Échu" est calculé automatiquement si la date
  d'échéance est dépassée sans validation.
- **Notifications par email (Outlook / Office 365)** :
  - Le contrôleur reçoit un email dès qu'un RMO soumet son fichier d'action sur un plan qu'il a créé.
  - Le RMO reçoit un email automatique (tâche planifiée quotidienne à 7h) si l'échéance de son plan
    d'action est dépassée sans clôture.

---

## 1. Prérequis sur le serveur Ubuntu 22.04

```bash
sudo apt update
sudo apt install -y curl git build-essential nginx postgresql postgresql-contrib
```

### Installer Node.js 20 LTS

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
node -v   # doit afficher v20.x
```

### Installer PM2 (gestionnaire de process Node)

```bash
sudo npm install -g pm2
```

---

## 2. Configuration de la base de données PostgreSQL

```bash
sudo -u postgres psql
```

Dans le prompt `psql` :

```sql
CREATE DATABASE controle_interne;
CREATE USER controle_user WITH ENCRYPTED PASSWORD 'un_mot_de_passe_fort';
GRANT ALL PRIVILEGES ON DATABASE controle_interne TO controle_user;
\q
```

---

## 3. Déploiement du backend

```bash
cd /opt
sudo git clone <votre-repo> controle-interne   # ou copiez le dossier via scp
cd controle-interne/backend
cp .env.example .env
nano .env   # renseignez DB_PASSWORD, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD, etc.

npm install --production
npm run migrate     # crée les tables
npm run seed         # crée le compte admin initial
```

Démarrer le backend avec PM2 :

```bash
pm2 start src/server.js --name controle-interne-api
pm2 save
pm2 startup   # suivre l'instruction affichée pour démarrer au boot
```

---

## 4. Build du frontend

```bash
cd /opt/controle-interne/frontend
npm install
npm run build
```

Le backend Express sert automatiquement le dossier `frontend/build` — donc après le build,
l'application complète est accessible directement sur le port du backend (4000 par défaut).

---

## 5. Configuration Nginx (reverse proxy + HTTPS interne)

Créer `/etc/nginx/sites-available/controle-interne` :

```nginx
server {
    listen 80;
    server_name controle-interne.votre-domaine-interne.local;

    client_max_body_size 20M;

    location / {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/controle-interne /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

Pour du HTTPS interne, utilisez votre propre autorité de certification ou `certbot` si le serveur
est joignable publiquement (sinon générez un certificat auto-signé ou interne à votre entreprise).

---

## 6. Première connexion

Rendez-vous sur l'URL configurée, connectez-vous avec `ADMIN_EMAIL` / `ADMIN_PASSWORD` définis dans `.env`.
Depuis le compte admin, créez les comptes Contrôleur et RMO via le menu **Utilisateurs**.

---

## 6bis. Configuration des emails (Outlook / Office 365)

Dans `backend/.env`, renseignez :

```
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=notifications-optika@votresociete.mg
SMTP_PASSWORD=mot_de_passe_de_la_boite_mail
SMTP_FROM=OPTIKA - Contrôle Interne <notifications-optika@votresociete.mg>
```

Points à vérifier auprès de votre administrateur Exchange/Microsoft 365 :
- L'authentification SMTP doit être **activée** pour ce compte (souvent désactivée par défaut sur M365).
- Si l'authentification moderne (OAuth2) est imposée, un mot de passe simple ne suffira pas — il faudra
  soit un mot de passe d'application dédié, soit passer par un relais SMTP interne autorisant
  l'authentification basique depuis l'IP du serveur.
- Sans configuration SMTP, l'application fonctionne normalement mais les emails sont simplement ignorés
  (un avertissement est affiché dans les logs PM2).

Redémarrez le backend après toute modification du `.env` :
```bash
pm2 restart controle-interne-api
```

---

## 7. Sauvegardes recommandées

```bash
# Sauvegarde de la base de données (à planifier via cron)
pg_dump -U controle_user controle_interne > backup_$(date +%F).sql

# Sauvegarde des fichiers uploadés (FDT + justificatifs)
tar -czf uploads_$(date +%F).tar.gz backend/uploads
```

---

## 8. Format du fichier Excel pour l'import du programme de contrôle

La première ligne est un en-tête (ignorée). Colonnes attendues dans cet ordre :

| Code | Processus | Activité | Risques | Contrôles | Sources | Support requis | Périodicité | Dates |
|------|-----------|----------|---------|-----------|---------|-----------------|-------------|-------|

- **Périodicité** : Hebdomadaire / Mensuelle / Trimestrielle / Semestrielle / Annuelle
- **Contrôles** : libellé/description du contrôle à réaliser
- **Sources** : origine de l'exigence (ex : nom de l'entité, réglementation, etc.)

Si le code existe déjà, le contrôle est **mis à jour** ; sinon il est **créé**.

## 9. Format attendu pour l'import d'une FDT (PDF)

Le dépôt d'une FDT ne se fait plus par Excel mais via le **module Feuilles de travail** de l'application :
le contrôleur saisit le code de contrôle concerné et importe directement le PDF signé de la feuille de
travail. La plateforme calcule elle-même la période en cours (semaine, mois, trimestre, semestre ou année
selon la périodicité du contrôle) et affiche 100% de conformité dès qu'une FDT existe pour cette période,
0% sinon. Une seule FDT est acceptée par contrôle et par période — un nouveau dépôt sur la même période
est refusé pour éviter les doublons (il faut d'abord supprimer l'ancienne FDT si besoin de la remplacer).
